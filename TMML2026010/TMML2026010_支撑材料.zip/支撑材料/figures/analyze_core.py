def rank_percentile(values: Sequence[float], higher_is_better: bool = True) -> np.ndarray:
    arr = np.asarray(values, dtype=float)
    ranks = rankdata(arr if higher_is_better else -arr, method="average")
    if len(arr) <= 1:
        return np.full(len(arr), 0.5)
    return (ranks - 1.0) / (len(arr) - 1.0)


def minmax(values: np.ndarray) -> np.ndarray:
    arr = np.asarray(values, dtype=float)
    lo = float(np.min(arr))
    hi = float(np.max(arr))
    if hi - lo <= 1e-12:
        return np.full(arr.shape, 0.5)
    return (arr - lo) / (hi - lo)



def analyze_scores(raw: np.ndarray, names: Sequence[str], normalization: str = "quantile") -> dict[str, object]:
    oriented = np.asarray(raw, dtype=float)
    if normalization == "quantile":
        z = np.column_stack([rank_percentile(oriented[:, j], higher_is_better=True) for j in range(oriented.shape[1])])
    elif normalization == "minmax":
        z = np.column_stack([minmax(oriented[:, j]) for j in range(oriented.shape[1])])
    elif normalization == "robust-z":
        z = np.column_stack([robust_z(oriented[:, j]) for j in range(oriented.shape[1])])
    else:
        raise ValueError(normalization)
    # Transparent mapping: C1 is the equal average of HLE and GPQA; every
    # other quality dimension is a single observed benchmark.  Speed and E2E
    # are deliberately absent from the quality matrix.
    q_by_ability = {
        ability: np.full(sum(item["ability"] == ability for item in INDICATORS), 1.0 / sum(item["ability"] == ability for item in INDICATORS))
        for ability in ABILITIES
    }
    ability_scores = np.column_stack([
        np.sum(z[:, [j for j, item in enumerate(INDICATORS) if item["ability"] == ability]] * q_by_ability[ability][None, :], axis=1)
        for ability in ABILITIES
    ])
    generic_weights = np.full(len(ABILITIES), 1.0 / len(ABILITIES))
    scenario_weights = {scenario: normalize_weights([SCENARIO_DEMAND[scenario][ability] for ability in ABILITIES]) for scenario in SCENARIOS}
    all_weights = {"问题一通用": generic_weights, **scenario_weights}
    score_tables = {key: ability_scores @ np.asarray(weights, dtype=float) for key, weights in all_weights.items()}
    rank_tables = {key: rankdata(-score, method="average") for key, score in score_tables.items()}
    eligibility = {
        scenario: {theta: np.all(ability_scores[:, [ABILITIES.index(a) for a in CRITICAL_ABILITIES[scenario]]] >= theta, axis=1) for theta in (0.20, 0.25, 0.30)}
        for scenario in SCENARIOS
    }
    return {
        "oriented": oriented,
        "z": z,
        "q_by_ability": q_by_ability,
        "ability_scores": ability_scores,
        "weights": all_weights,
        "scores": score_tables,
        "ranks": rank_tables,
        "eligibility": eligibility,
        "normalization": normalization,
        "names": list(names),
    }


def normalize_weights(values: Sequence[float]) -> np.ndarray:

    arr = np.asarray(values, dtype=float)
    total = float(np.sum(arr))
    return arr / total if total else np.full(len(arr), 1.0 / len(arr))


def rank_rows(names: Sequence[str], scores: Mapping[str, np.ndarray], ranks: Mapping[str, np.ndarray]) -> list[dict[str, object]]:
    rows = []
    for i, name in enumerate(names):
        row: dict[str, object] = {"model_name": name}
        for key, values in scores.items():
            row[f"{key}_score"] = round(float(values[i]), 8)
            row[f"{key}_rank"] = int(round(float(ranks[key][i])))
        rows.append(row)
    return rows


def pareto_frontier(rows: Sequence[Mapping[str, object]], performance_key: str, cost_key: str) -> list[dict[str, object]]:
    sorted_rows = sorted(rows, key=lambda row: (float(row[cost_key]), -float(row[performance_key])))
    best = -float("inf")
    frontier = []
    for row in sorted_rows:
        performance = float(row[performance_key])
        if performance > best + 1e-12:
            frontier.append(dict(row))
            best = performance
    return frontier


def budget_segments(rows: Sequence[Mapping[str, object]], score_key: str, cost_key: str, latency_key: str, latency_limit: float) -> list[dict[str, object]]:
    eligible = [row for row in rows if float(row[latency_key]) <= latency_limit]
    if not eligible:
        return [{"budget_lower_usd_per_1000": 0.0, "budget_upper_usd_per_1000": "inf", "recommended_model": "无可行模型", "score": "", "latency_seconds": "", "latency_limit": latency_limit, "status": "无可行模型"}]
    min_cost = min(float(row[cost_key]) for row in eligible)
    unique_costs = sorted({round(float(row[cost_key]), 10) for row in eligible})
    switches: list[tuple[float, Mapping[str, object]]] = []
    previous_model = None
    for cost in unique_costs:
        candidates = [row for row in eligible if float(row[cost_key]) <= cost + 1e-9]
        # At a tied cost, keep the highest-performance model.  This prevents
        # zero-width intervals such as [64,64) from entering the table.
        best_row = max(candidates, key=lambda row: (float(row[score_key]), -float(row[latency_key])))
        if best_row["model_name"] != previous_model:
            switches.append((cost, best_row))
            previous_model = best_row["model_name"]
    segments = []
    if min_cost > 1e-12:
        segments.append({"budget_lower_usd_per_1000": 0.0, "budget_upper_usd_per_1000": round(min_cost, 8), "recommended_model": "无可行模型", "score": "", "latency_seconds": "", "latency_limit": latency_limit, "status": "无可行模型"})
    for i, (start, row) in enumerate(switches):
        end = switches[i + 1][0] if i + 1 < len(switches) else float("inf")
        if end <= start + 1e-12:
            continue
        segments.append({"budget_lower_usd_per_1000": round(start, 8), "budget_upper_usd_per_1000": "inf" if math.isinf(end) else round(end, 8), "recommended_model": row["model_name"], "score": round(float(row[score_key]), 8), "latency_seconds": round(float(row[latency_key]), 8), "latency_limit": latency_limit})
    return segments


TOKEN_CHART_FILES = {
    "HLE": "hle-charts.json",
    "GPQA": "gpqa-diamond-charts.json",
    "LCR": "aa-lcr-charts.json",
    "SciCode": "scicode-charts.json",
    "tau3": "tau3-banking-charts.json",
    "Terminal": "terminalbench-v2-1-charts.json",
}



def parse_token_label(label: object) -> float | None:
    """Parse the compact labels used by the public Token Usage SVGs."""
    text = str(label).strip().replace(",", "")
    if not text:
        return None
    match = re.fullmatch(r"([0-9]+(?:\.[0-9]+)?)\s*([kK])?", text)
    if not match:
        return None
    number = float(match.group(1))
    if match.group(2):
        number *= 1000.0
    return number


def load_compute_proxy(names: Sequence[str]) -> dict[str, dict[str, object]]:

def scenario_decomposition(names: Sequence[str], analysis: Mapping[str, object]) -> None:
    records = []
    scenarios = list(SCENARIO_INTENSITY)
    for a_i in range(len(scenarios)):
        for b_i in range(a_i + 1, len(scenarios)):
            a, b = scenarios[a_i], scenarios[b_i]
            delta_w = np.asarray(analysis["weights"][b]) - np.asarray(analysis["weights"][a])
            for i, name in enumerate(names):
                row = {"model_name": name, "from_scenario": a, "to_scenario": b}
                contributions = []
                for j, ability in enumerate(ABILITIES):
                    value = float(delta_w[j] * analysis["ability_scores"][i, j])
                    row[f"delta_{ability}"] = round(value, 8)
                    contributions.append(value)
                row["delta_total"] = round(float(np.sum(contributions)), 8)
                row["direct_score_difference"] = round(float(analysis["scores"][b][i] - analysis["scores"][a][i]), 8)
                row["rank_from"] = int(analysis["ranks"][a][i])
                row["rank_to"] = int(analysis["ranks"][b][i])
                records.append(row)
    write_csv(RESULTS / "scenario_decomposition.csv", records)


def fit_models(x: np.ndarray, y: np.ndarray) -> dict[str, dict[str, object]]:
    """Fit the five prespecified curves and evaluate LOOCV RMSE/AICc."""
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    eps = max(float(np.min(x)) * 1e-6, 1e-8)

    def linear_fit(xx: np.ndarray, yy: np.ndarray) -> tuple[Callable[[np.ndarray], np.ndarray], int, dict[str, float]]:
        coef = np.linalg.lstsq(np.column_stack([np.ones(len(xx)), xx]), yy, rcond=None)[0]
        return lambda v: coef[0] + coef[1] * np.asarray(v), 2, {"a": float(coef[0]), "b": float(coef[1])}

    def log_fit(xx: np.ndarray, yy: np.ndarray) -> tuple[Callable[[np.ndarray], np.ndarray], int, dict[str, float]]:
        coef = np.linalg.lstsq(np.column_stack([np.ones(len(xx)), np.log(xx + eps)]), yy, rcond=None)[0]
        return lambda v: coef[0] + coef[1] * np.log(np.asarray(v) + eps), 2, {"a": float(coef[0]), "b": float(coef[1]), "eps": eps}

    def power_fit(xx: np.ndarray, yy: np.ndarray) -> tuple[Callable[[np.ndarray], np.ndarray], int, dict[str, float]]:
        safe_y = np.maximum(yy, 1e-8)
        coef = np.linalg.lstsq(np.column_stack([np.ones(len(xx)), np.log(xx + eps)]), np.log(safe_y), rcond=None)[0]
        a, b = float(np.exp(coef[0])), float(coef[1])
        return lambda v: a * np.power(np.asarray(v) + eps, b), 2, {"a": a, "b": b, "eps": eps}

    def sat_fn(v: np.ndarray, a: float, b: float, tau: float) -> np.ndarray:
        return a - b * np.exp(-np.asarray(v) / max(tau, 1e-8))

    def saturation_fit(xx: np.ndarray, yy: np.ndarray) -> tuple[Callable[[np.ndarray], np.ndarray], int, dict[str, float]]:
        p0 = [float(np.max(yy)), float(np.max(yy) - np.min(yy)), max(float(np.median(xx)), 1e-4)]
        bound_lo = [-2.0, -2.0, 1e-8]
        bound_hi = [2.0, 4.0, max(float(np.max(xx) * 100.0), 1.0)]
        params, _ = curve_fit(sat_fn, xx, yy, p0=p0, bounds=(bound_lo, bound_hi), maxfev=20_000)
        return lambda v: sat_fn(np.asarray(v), *params), 3, {"a": float(params[0]), "b": float(params[1]), "tau": float(params[2])}

    def breakpoint_fit(xx: np.ndarray, yy: np.ndarray) -> tuple[Callable[[np.ndarray], np.ndarray], int, dict[str, float]]:
        candidates = np.unique(np.quantile(xx, np.linspace(0.15, 0.85, 15)))
        best = None
        for knot in candidates:
            design = np.column_stack([np.ones(len(xx)), xx, np.maximum(0.0, xx - knot)])
            coef = np.linalg.lstsq(design, yy, rcond=None)[0]
            resid = yy - design @ coef
            rss = float(np.sum(resid * resid))
            if best is None or rss < best[0]:
                best = (rss, float(knot), coef)
        if best is None:
            raise ValueError("断点候选为空")
        _, knot, coef = best
        return lambda v: np.column_stack([np.ones(len(np.asarray(v))), np.asarray(v), np.maximum(0.0, np.asarray(v) - knot)]) @ coef, 4, {"a": float(coef[0]), "b1": float(coef[1]), "b2_change": float(coef[2]), "knot": knot}

    fitters: dict[str, Callable[[np.ndarray, np.ndarray], tuple[Callable[[np.ndarray], np.ndarray], int, dict[str, float]]]] = {
        "线性": linear_fit, "对数": log_fit, "幂函数": power_fit, "饱和": saturation_fit, "单断点": breakpoint_fit,
    }
    outputs: dict[str, dict[str, object]] = {}
    n = len(x)
    for name, fitter in fitters.items():
        try:
            pred_fn, p, params = fitter(x, y)
            pred = np.asarray(pred_fn(x), dtype=float)
            residual = y - pred
            rss = float(np.sum(residual * residual))
            aicc = n * math.log(max(rss / n, 1e-12)) + 2 * p + (2 * p * (p + 1) / max(n - p - 1, 1))
            loocv_errors = []
            for holdout in range(n):
                mask = np.ones(n, dtype=bool)
                mask[holdout] = False
                try:
                    fold_fn, _, _ = fitter(x[mask], y[mask])
                    loocv_errors.append(float(y[holdout] - fold_fn(np.asarray([x[holdout]]))[0]))
                except Exception:
                    loocv_errors.append(float("nan"))
            valid = np.asarray(loocv_errors, dtype=float)
            cv_rmse = float(np.sqrt(np.nanmean(valid * valid))) if np.any(np.isfinite(valid)) else float("inf")
            outputs[name] = {"params": params, "n_params": p, "pred": pred, "residual": residual, "rss": rss, "aicc": float(aicc), "loocv_rmse": cv_rmse}
        except Exception as exc:
            outputs[name] = {"params": {}, "n_params": 0, "pred": np.full(n, np.nan), "residual": np.full(n, np.nan), "rss": np.nan, "aicc": np.inf, "loocv_rmse": np.inf, "error": str(exc)}
    return outputs


def cost_fit_outputs(scenario_rows: Mapping[str, Sequence[Mapping[str, object]]]) -> None:
    summary = []
    point_rows = []
    for scenario, rows in scenario_rows.items():
        # Cost-performance curves are an engineering extension of the hard
        # gate, so non-recommendable quality configurations do not determine
        # the selected curve or its budget interpretation.
        rows = [row for row in rows if row.get("eligible_theta_025") in {True, "True"}]
        if len(rows) < 3:
            raise ValueError(f"{scenario} I_is(0.25) 相对短板资格样本不足以拟合成本曲线: {len(rows)}")
        x = np.asarray([float(row["cost_usd_per_1000_tasks"]) for row in rows])
        y = np.asarray([float(row["performance"]) for row in rows])
        fits = fit_models(x, y)
        best = min(fits, key=lambda name: (float(fits[name]["loocv_rmse"]), float(fits[name]["aicc"])))
        rank_corr, rank_p = spearmanr(x, y)
        for model, result in fits.items():
            tss = float(np.sum((y - np.mean(y)) ** 2))
            r2 = float(1.0 - result["rss"] / tss) if tss > 1e-12 and np.isfinite(result["rss"]) else float("nan")
