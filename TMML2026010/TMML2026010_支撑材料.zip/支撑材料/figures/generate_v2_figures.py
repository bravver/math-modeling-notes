from __future__ import annotations

import csv
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyBboxPatch
from scipy.cluster.hierarchy import dendrogram, linkage
from scipy.spatial.distance import squareform


HERE = Path(__file__).resolve().parent
RESULTS = HERE.parents[1] / "analysis_engine" / "results"

plt.rcParams.update(
    {
        "font.family": "sans-serif",
        "font.sans-serif": ["SimSun", "Noto Sans CJK SC", "DejaVu Sans"],
        "axes.unicode_minus": False,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "figure.dpi": 160,
        "axes.titlesize": 12,
        "axes.labelsize": 10,
        "xtick.labelsize": 8,
        "ytick.labelsize": 8,
        "legend.fontsize": 8,
    }
)

BLUE = "#2F6B9A"
TEAL = "#2C8C8C"
ORANGE = "#D17A22"
RED = "#B84A4A"
GRAY = "#6D7480"
LIGHT = "#EAF2F8"


def rows(name: str):
    with (RESULTS / name).open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def save(fig, name: str):
    fig.savefig(HERE / name, format="pdf", bbox_inches="tight", pad_inches=0.08)
    plt.close(fig)


def fig01():
    fig, ax = plt.subplots(figsize=(12.2, 2.55))
    ax.set_xlim(0, 12.2)
    ax.set_ylim(0, 2.55)
    ax.axis("off")
    labels = [
        "公开 Benchmark",
        "准入、正向化\n与分位数标准化",
        "7 项核心评价维度\nC",
        "通用/场景评价\nS, I",
        "预算与工程决策\nD(B)",
    ]
    xs = [0.15, 2.55, 5.0, 7.45, 9.9]
    widths = [1.85, 2.0, 1.8, 1.8, 2.05]
    for x, w, label in zip(xs, widths, labels):
        patch = FancyBboxPatch(
            (x, 0.75),
            w,
            0.85,
            boxstyle="round,pad=0.035,rounding_size=0.12",
            linewidth=1.2,
            edgecolor=BLUE,
            facecolor=LIGHT,
        )
        ax.add_patch(patch)
        ax.text(x + w / 2, 1.175, label, ha="center", va="center", fontsize=10.5)
    for x1, w1, x2 in zip(xs[:-1], widths[:-1], xs[1:]):
        ax.annotate(
            "",
            xy=(x2 - 0.10, 1.175),
            xytext=(x1 + w1 + 0.10, 1.175),
            arrowprops={"arrowstyle": "->", "lw": 1.4, "color": GRAY},
        )
    ax.text(
        6.1,
        2.18,
        "公开测评  →  评价维度  →  场景效用  →  工程选型",
        ha="center",
        va="center",
        fontsize=12,
        color="#333333",
    )
    save(fig, "fig01_method_flow.pdf")


def fig02():
    labels = [
        "HLE",
        "GPQA",
        "Omni Accuracy",
        "Non-Hallucination",
        "AA-LCR",
        "SciCode",
        "Terminal",
        "tau3-Banking",
        "IFBench",
        "LiveCodeBench",
        "MMMU-Pro",
        "Global-MMLU-Lite",
    ]
    values = [1] * 8 + [0.4074, 0.0741, 0.5185, 0.0741]
    colors = [BLUE] * 8 + [ORANGE] * 4
    fig, ax = plt.subplots(figsize=(8.2, 4.8))
    y = np.arange(len(labels))
    ax.barh(y, values, color=colors, alpha=0.9)
    ax.axvline(0.7, color=RED, ls="--", lw=1.2, label="70% 主评价准入线")
    ax.set_yticks(y, labels)
    ax.invert_yaxis()
    ax.set_xlim(0, 1.08)
    ax.set_xlabel("27 个质量完整配置中的覆盖率")
    ax.set_title("核心与扩展指标覆盖率")
    for yi, value in zip(y, values):
        ax.text(value + 0.015, yi, f"{value:.1%}", va="center", fontsize=8)
    ax.legend(loc="lower right", frameon=False)
    ax.grid(axis="x", alpha=0.2)
    save(fig, "fig02_coverage.pdf")


def fig03():
    data = rows("spearman_matrix.csv")
    keys = ["HLE", "GPQA", "Accuracy", "NonHallucination", "LCR", "SciCode", "Terminal", "tau3"]
    short = ["HLE", "GPQA", "Accuracy", "NonHall", "LCR", "SciCode", "Terminal", "tau3"]
    matrix = np.array([[float(r[k]) for k in keys] for r in data])
    fig, ax = plt.subplots(figsize=(7.2, 6.2))
    im = ax.imshow(matrix, cmap="coolwarm", vmin=-1, vmax=1)
    ax.set_xticks(range(8), short, rotation=45, ha="right")
    ax.set_yticks(range(8), short)
    ax.set_title("八项核心观测的 Spearman 秩相关")
    for i in range(8):
        for j in range(8):
            color = "white" if abs(matrix[i, j]) > 0.55 else "#333333"
            ax.text(j, i, f"{matrix[i,j]:.2f}", ha="center", va="center", fontsize=7, color=color)
    fig.colorbar(im, ax=ax, shrink=0.82, label="rho")
    fig.tight_layout()
    save(fig, "fig03_spearman_heatmap.pdf")


def fig04():
    data = rows("spearman_matrix.csv")
    keys = ["HLE", "GPQA", "Accuracy", "NonHallucination", "LCR", "SciCode", "Terminal", "tau3"]
    labels = ["HLE", "GPQA", "Accuracy", "NonHall", "LCR", "SciCode", "Terminal", "tau3"]
    matrix = np.array([[float(r[k]) for k in keys] for r in data])
    distance = 1 - matrix
    np.fill_diagonal(distance, 0.0)
    linkage_matrix = linkage(squareform(distance, checks=False), method="average")
    fig, ax = plt.subplots(figsize=(7.5, 5.0))
    dendrogram(
        linkage_matrix,
        labels=labels,
        orientation="right",
        ax=ax,
        color_threshold=0.15,
        above_threshold_color=GRAY,
    )
    ax.axvline(0.15, ls="--", lw=1.0, color=RED, label="rho=0.85 预警线")
    ax.set_xlabel("距离 d = 1 - rho")
    ax.set_title("核心观测的层次聚类诊断")
    ax.legend(frameon=False, loc="lower right")
    fig.tight_layout()
    save(fig, "fig04_indicator_dendrogram.pdf")


def fig05():
    data = rows("rankings.csv")
    data.sort(key=lambda r: int(r["问题一通用_rank"]))
    data = data[:12][::-1]
    names = [r["model_name"].replace(" (", "\n(") for r in data]
    scores = [float(r["问题一通用_score"]) for r in data]
    fig, ax = plt.subplots(figsize=(8.3, 5.3))
    y = np.arange(len(names))
    colors = [ORANGE if "Kimi" in n else BLUE for n in names]
    ax.barh(y, scores, color=colors)
    ax.set_yticks(y, names)
    ax.set_xlim(0, 0.9)
    ax.set_xlabel("通用质量得分")
    ax.set_title("27 个质量完整配置的通用质量排名")
    for yi, value in zip(y, scores):
        ax.text(value + 0.012, yi, f"{value:.3f}", va="center", fontsize=8)
    ax.grid(axis="x", alpha=0.2)
    save(fig, "fig05_overall_ranking.pdf")


def fig06():
    data = rows("ability_scores.csv")
    kimi = next(r for r in data if r["model_name"].startswith("Kimi K3"))
    labels = ["C1\n科学推理", "C2\n知识正确", "C3\n事实可靠", "C4\n长文本", "C5\n科学代码", "C6\n软件工具", "C7\n交互完成"]
    keys = ["C1", "C2", "C3", "C4", "C5", "C6", "C7"]
    values = [float(kimi[k]) for k in keys]
    fig, ax = plt.subplots(figsize=(8.0, 4.8))
    x = np.arange(7)
    ax.bar(x, values, color=[BLUE, BLUE, RED, TEAL, TEAL, BLUE, TEAL], width=0.62)
    ax.axhline(0.5, color=GRAY, ls="--", lw=1.1, label="样本均值 0.5")
    ax.set_xticks(x, labels)
    ax.set_ylim(0, 1.08)
    ax.set_ylabel("分位数维度得分")
    ax.set_title("Kimi K3（max）的七项核心评价维度")
    ax.legend(frameon=False, loc="upper right")
    for xi, value in zip(x, values):
        ax.text(xi, value + 0.025, f"{value:.3f}", ha="center", fontsize=8)
    ax.grid(axis="y", alpha=0.2)
    save(fig, "fig06_kimi_profile.pdf")


def fig07():
    data = rows("rankings.csv")
    scenarios = [
        ("科研长文本", "科研长文本_score", "科研长文本_rank"),
        ("大众日常对话", "大众日常对话_score", "大众日常对话_rank"),
        ("计算机代码开发", "计算机代码开发_score", "计算机代码开发_rank"),
    ]
    top = []
    for title, score_key, rank_key in scenarios:
        current = sorted(data, key=lambda r: int(r[rank_key]))[:5]
        top.append((title, current, score_key))
    fig, axes = plt.subplots(1, 3, figsize=(12.0, 4.8), sharey=True)
    for ax, (title, current, score_key) in zip(axes, top):
        current = current[::-1]
        names = [r["model_name"].replace(" (", "\n(") for r in current]
        vals = [float(r[score_key]) for r in current]
        colors = [ORANGE if "Kimi" in n else BLUE for n in names]
        ax.barh(np.arange(5), vals, color=colors)
        ax.set_yticks(np.arange(5), names)
        ax.set_xlim(0.65, 0.86)
        ax.set_title(title)
        ax.grid(axis="x", alpha=0.2)
        for yi, value in enumerate(vals):
            ax.text(value + 0.003, yi, f"{value:.3f}", va="center", fontsize=7)
    axes[0].set_ylabel("模型配置（前五）")
    fig.suptitle("三类场景的综合得分排名（27 个配置）", y=1.02)
    fig.tight_layout()
    save(fig, "fig07_scenario_ranking.pdf")


def fig08():
    data = rows("scenario_decomposition.csv")
    kimi = [r for r in data if r["model_name"].startswith("Kimi K3")]
    pairs = [
        ("科研 -> 日常", "科研长文本", "大众日常对话"),
        ("科研 -> 代码", "科研长文本", "计算机代码开发"),
        ("日常 -> 代码", "大众日常对话", "计算机代码开发"),
    ]
    keys = ["C1", "C2", "C3", "C4", "C5", "C6", "C7"]
    fig, axes = plt.subplots(1, 3, figsize=(12.0, 3.8), sharey=True)
    for ax, (title, source, target) in zip(axes, pairs):
        row = next(r for r in kimi if r["from_scenario"] == source and r["to_scenario"] == target)
        vals = [float(row[f"delta_{k}"]) for k in keys]
        colors = [RED if v < 0 else TEAL for v in vals]
        ax.bar([f"C{i}" for i in range(1, 8)], vals, color=colors)
        ax.axhline(0, color=GRAY, lw=0.8)
        ax.set_ylim(-0.32, 0.29)
        ax.set_title(f"{title}\n总变化 {float(row['delta_total']):+.3f}")
        ax.grid(axis="y", alpha=0.2)
        for x, value in enumerate(vals):
            ax.text(x, value + (0.008 if value >= 0 else -0.015), f"{value:+.3f}", ha="center", va="bottom" if value >= 0 else "top", fontsize=7)
    axes[0].set_ylabel("对场景得分变化的贡献")
    fig.suptitle("Kimi K3 的跨场景维度贡献分解", y=1.03)
    fig.tight_layout()
    save(fig, "fig08_kimi_decomposition.pdf")


def fig09():
    fig, axes = plt.subplots(1, 3, figsize=(12.0, 4.2), sharey=True)
    scenarios = [
        ("科研长文本", "q3_pareto_quality_cost_latency_科研长文本.csv", "科研质量"),
        ("大众日常对话", "q3_pareto_quality_cost_latency_大众日常对话.csv", "日常质量"),
        ("计算机代码开发", "q3_pareto_quality_cost_latency_计算机代码开发.csv", "代码质量"),
    ]
    for ax, (title, filename, ylabel) in zip(axes, scenarios):
        data = rows(filename)
        costs = [float(r["cost_usd_per_1000_tasks"]) for r in data if float(r["cost_usd_per_1000_tasks"]) > 0]
        quality = [float(r["quality_score"]) for r in data if float(r["cost_usd_per_1000_tasks"]) > 0]
        names = [r["model_name"] for r in data if float(r["cost_usd_per_1000_tasks"]) > 0]
        ax.scatter(costs, quality, s=20, alpha=0.48, color=BLUE)
        for c, q, n in zip(costs, quality, names):
            if "Kimi" in n:
                ax.scatter([c], [q], color=ORANGE, s=38, zorder=3)
                ax.annotate("Kimi", (c, q), xytext=(3, 4), textcoords="offset points", fontsize=7)
        ax.set_xscale("log")
        ax.set_title(title)
        ax.set_xlabel("费用（USD/1000任务，对数轴）")
        ax.grid(alpha=0.2)
    axes[0].set_ylabel("原始场景质量")
    fig.suptitle("主 Pareto 观察：质量、费用与统一协议时延", y=1.02)
    fig.tight_layout()
    save(fig, "fig09_pareto.pdf")


def fig10():
    fig, axes = plt.subplots(1, 3, figsize=(12.0, 4.2), sharey=True)
    scenarios = [
        ("科研长文本", "q3_budget_segments_科研长文本_medium.csv"),
        ("大众日常对话", "q3_budget_segments_大众日常对话_medium.csv"),
        ("计算机代码开发", "q3_budget_segments_计算机代码开发_medium.csv"),
    ]
    for ax, (title, filename) in zip(axes, scenarios):
        data = rows(filename)
        x = [float(r["budget_lower_usd_per_1000"]) for r in data]
        x.append(300 if "科研" in title else (20 if "日常" in title else 120))
        y = [float(r["quality_score"]) if r["quality_score"] else np.nan for r in data]
        y.append(y[-1] if np.isfinite(y[-1]) else 0)
        labels = [r["recommended_model"].replace(" (max)", "").replace(" (high)", "") for r in data]
        for i in range(len(data) - 1):
            left = float(data[i]["budget_lower_usd_per_1000"])
            right_raw = data[i]["budget_upper_usd_per_1000"]
            right = float(right_raw) if right_raw != "inf" else x[-1]
            value = float(data[i]["quality_score"]) if data[i]["quality_score"] else np.nan
            if np.isfinite(value):
                ax.hlines(value, left, right, color=ORANGE if "Kimi" in labels[i] else BLUE, lw=4)
                ax.text((left + right) / 2, value + 0.012, labels[i], ha="center", fontsize=7)
        ax.set_xscale("symlog", linthresh=0.5)
        ax.set_title(title)
        ax.set_xlabel("预算（USD/1000任务）")
        ax.grid(alpha=0.2)
    axes[0].set_ylabel("可行集合中的最高场景得分")
    fig.suptitle("中等负载下的预算切换路径", y=1.02)
    fig.tight_layout()
    save(fig, "fig10_budget_switch.pdf")


def fig11():
    fit = rows("q3_fit_summary.csv")
    selected = [r for r in fit if r["selected"] == "True"]
    scenarios = [
        ("科研长文本", "科研长文本", "q3_costs_科研长文本.csv"),
        ("大众日常对话", "大众日常对话", "q3_costs_大众日常对话.csv"),
        ("计算机代码开发", "计算机代码开发", "q3_costs_计算机代码开发.csv"),
    ]
    fig, axes = plt.subplots(1, 3, figsize=(12.0, 4.2), sharey=True)
    for ax, (title, key, filename) in zip(axes, scenarios):
        data = rows(filename)
        costs = np.array([float(r["cost_usd_per_1000_tasks"]) for r in data if float(r["cost_usd_per_1000_tasks"]) > 0])
        quality = np.array([float(r["quality_score"]) for r in data if float(r["cost_usd_per_1000_tasks"]) > 0])
        ax.scatter(costs, quality, s=22, color=BLUE, alpha=0.6, label="观测配置")
        ax.set_xscale("log")
        ax.set_title(title)
        ax.set_xlabel("费用（USD/1000任务）")
        ax.grid(alpha=0.2)
        if key == "科研长文本":
            a, b, knot = 0.4555297771, 0.0010157281, 300.0
            after = -0.0000728189
            xx = np.geomspace(max(0.1, costs.min()), costs.max() * 1.05, 160)
            yy = np.where(xx <= knot, a + b * xx, a + b * knot + after * (xx - knot))
            label = "单断点"
        elif key == "大众日常对话":
            a, b, eps = 0.3588431007, 0.1058301183, 1.72e-6
            xx = np.geomspace(max(0.1, costs.min()), costs.max() * 1.05, 160)
            yy = a + b * np.log(xx + eps)
            label = "对数"
        else:
            a, b, tau = 0.8262202741, 0.4021155650, 68.1340337
            xx = np.geomspace(max(0.1, costs.min()), costs.max() * 1.05, 160)
            yy = a - b * np.exp(-xx / tau)
            label = "饱和"
        ax.plot(xx, yy, color=ORANGE, lw=1.8, label=label)
        ax.legend(frameon=False, loc="lower right")
    axes[0].set_ylabel("原始场景质量")
    fig.suptitle("成本—质量关系的入选函数", y=1.02)
    fig.tight_layout()
    save(fig, "fig11_cost_fit.pdf")


def fig12():
    data = rows("compute_proxy.csv")
    names = [r["model_name"] for r in data]
    tokens = np.array([float(r["compute_burden_tokens_mean"]) for r in data])
    eff = np.array([float(r["compute_efficiency_percentile_mean"]) for r in data])
    fig, axes = plt.subplots(1, 3, figsize=(12.0, 4.1))
    for ax, title in zip(axes, ["科研长文本", "大众日常对话", "计算机代码开发"]):
        costs = np.array([0.0] * len(names))
        quality = np.array([0.0] * len(names))
        data_key = {"科研长文本": "科研长文本", "大众日常对话": "大众日常对话", "计算机代码开发": "计算机代码开发"}[title]
        cost_rows = rows(f"q3_costs_{data_key}.csv")
        cost_map = {r["model_name"]: float(r["cost_usd_per_1000_tasks"]) for r in cost_rows}
        rank_rows = rows("rankings.csv")
        quality_map = {r["model_name"]: float(r[f"{data_key}_score"]) for r in rank_rows}
        for i, name in enumerate(names):
            costs[i] = cost_map.get(name, np.nan)
            quality[i] = quality_map.get(name, np.nan)
        valid = np.isfinite(costs) & np.isfinite(quality)
        ax.scatter(tokens[valid], costs[valid], c=quality[valid], cmap="viridis", s=28, alpha=0.75)
        kimi_idx = [i for i, name in enumerate(names) if "Kimi K3" in name and valid[i]]
        if kimi_idx:
            ax.scatter(tokens[kimi_idx], costs[kimi_idx], facecolors="none", edgecolors=ORANGE, s=100, lw=1.6)
        ax.set_title(title)
        ax.set_xlabel("HLE/GPQA 平均输出 token")
        ax.set_ylabel("直接费用（USD/1000任务）")
        ax.grid(alpha=0.2)
    fig.suptitle("生成侧负担代理：仅覆盖 2/8 个核心基准", y=1.03)
    fig.tight_layout()
    save(fig, "fig12_compute_pareto.pdf")


if __name__ == "__main__":
    fig01()
    fig02()
    fig03()
    fig04()
    fig05()
    fig06()
    fig07()
    fig08()
    fig09()
    fig10()
    fig11()
    fig12()
