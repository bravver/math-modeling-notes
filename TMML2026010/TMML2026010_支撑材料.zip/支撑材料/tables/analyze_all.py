"""Reproducible analysis engine for Problem B.

The script deliberately uses only the frozen public data files.  It does not
download data, infer missing values, or treat Artificial Analysis' cost-per-
intelligence-task field as a token price.  All generated files stay below the
analysis_engine directory.
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import platform
import re
import sys
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable, Iterable, Mapping, Sequence

import matplotlib

matplotlib.use("Agg")
import matplotlib.font_manager as fm
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyBboxPatch
from scipy.cluster.hierarchy import dendrogram, fcluster, linkage
from scipy.optimize import curve_fit
from scipy.spatial.distance import squareform
from scipy.stats import kendalltau, rankdata, spearmanr


SEED = 20260817
RNG = np.random.default_rng(SEED)
SCRIPT = Path(__file__).resolve()
# The same source is copied into two formally supported layouts:
#   workspace/workstreams/analysis_engine/src/analyze.py
#   package/src/model/analyze.py
# Detect the package by its processed-data anchor rather than by cwd, so the
# extracted support package can be rerun from any directory.
PACKAGE_ROOT = SCRIPT.parents[2]
if (PACKAGE_ROOT / "data" / "processed" / "scores_long.csv").exists():
    ROOT = PACKAGE_ROOT
    OUT = PACKAGE_ROOT
    DATA_DIR = PACKAGE_ROOT / "data" / "processed"
    RAW_DATA_DIR = PACKAGE_ROOT / "data" / "raw"
    RESULTS = OUT / "results" / "tables"
    FIGURES = OUT / "results" / "figures"
else:
    # src/analyze.py -> analysis_engine/src; project root is three parents up.
    ROOT = SCRIPT.parents[3]
    OUT = SCRIPT.parents[1]
    DATA_DIR = ROOT / "workstreams" / "aa_data_collection"
    RAW_DATA_DIR = DATA_DIR / "raw"
    RESULTS = OUT / "results"
    FIGURES = RESULTS / "figures"

INDICATORS = [
    {"id": "HLE", "source": "HLE", "label": "HLE", "direction": "benefit", "ability": "C1"},
    {"id": "GPQA", "source": "GPQA Diamond", "label": "GPQA Diamond", "direction": "benefit", "ability": "C1"},
    {"id": "Accuracy", "source": "AA-Omniscience Accuracy", "label": "Omniscience Accuracy", "direction": "benefit", "ability": "C2"},
    {"id": "NonHallucination", "source": "AA-Omniscience Non-Hallucination (derived)", "label": "Non-Hallucination", "direction": "benefit", "ability": "C3"},
    {"id": "LCR", "source": "AA-LCR", "label": "AA-LCR", "direction": "benefit", "ability": "C4"},
    {"id": "SciCode", "source": "SciCode", "label": "SciCode", "direction": "benefit", "ability": "C5"},
    {"id": "Terminal", "source": "Terminal-Bench v2.1", "label": "Terminal-Bench", "direction": "benefit", "ability": "C6"},
    {"id": "tau3", "source": "tau3-Banking", "label": "tau3-Banking", "direction": "benefit", "ability": "C7"},
]
ABILITY_LABELS = {
    "C1": "科学与复杂推理",
    "C2": "知识正确性",
    "C3": "知识边界校准",
    "C4": "长文本理解",
    "C5": "代码与科学计算",
    "C6": "软件工程与工具执行",
    "C7": "指令交互与任务完成",
}
ABILITIES = list(ABILITY_LABELS)
BENCHMARK_SOURCES = {x["id"]: x for x in INDICATORS}

# The correlation screen is a diagnostic step, not an automatic deletion
# rule.  These reviews make the semantic decision reproducible for every
# pair that crosses rho >= .85 under the frozen seven-dimension mapping.
HIGH_CORR_REVIEW = {
    ("GPQA", "HLE"): {
        "constructs_highly_overlapping": "是",
        "substantive_redundancy": "是（同构指标）",
        "final_treatment": "合并进入 C1 内等权融合",
        "treatment_reason": "两项均主要测科学与复杂推理；保留两项观测以降低单一测评的偶然性，再在同一维度内等权融合。",
    },
    ("HLE", "SciCode"): {
        "constructs_highly_overlapping": "否",
        "substantive_redundancy": "否",
        "final_treatment": "分别保留（C1、C5）",
        "treatment_reason": "相关排序较高，但 HLE 偏跨学科知识与推理，SciCode 偏科学计算代码生成与执行，任务构念和误差来源不同。",
    },
    ("HLE", "Terminal"): {
        "constructs_highly_overlapping": "否",
        "substantive_redundancy": "否",
        "final_treatment": "分别保留（C1、C6）",
        "treatment_reason": "HLE 主要观察学术知识与复杂推理，Terminal-Bench 观察终端环境中的软件工程与工具执行，不能由相关性替代。",
    },
    ("HLE", "tau3"): {
        "constructs_highly_overlapping": "否",
        "substantive_redundancy": "否",
        "final_treatment": "分别保留（C1、C7）",
        "treatment_reason": "HLE 的核心是学术问题求解，tau3-Banking 的核心是多轮交互、工具调用和任务完成，场景构念不同。",
    },
    ("GPQA", "Terminal"): {
        "constructs_highly_overlapping": "否",
        "substantive_redundancy": "否",
        "final_treatment": "分别保留（C1、C6）",
        "treatment_reason": "GPQA 侧重博士级科学知识与推理，Terminal-Bench 侧重终端软件工程和执行闭环，保留以避免工程维度被科学推理代理。",
    },
    ("Accuracy", "Terminal"): {
        "constructs_highly_overlapping": "否",
        "substantive_redundancy": "否",
        "final_treatment": "分别保留（C2、C6）",
        "treatment_reason": "Accuracy 描述跨领域知识回答正确性，Terminal-Bench 描述真实终端任务执行，二者虽同向但测量对象不同。",
    },
    ("SciCode", "Terminal"): {
        "constructs_highly_overlapping": "否（部分交叉）",
        "substantive_redundancy": "否",
        "final_treatment": "分别保留（C5、C6）",
        "treatment_reason": "二者都涉及代码，但 SciCode 偏科学计算代码质量，Terminal-Bench 偏系统环境中的软件工程与工具执行，保留其互补信息。",
    },
    ("Terminal", "tau3"): {
        "constructs_highly_overlapping": "否（部分交叉）",
        "substantive_redundancy": "否",
        "final_treatment": "分别保留（C6、C7）",
        "treatment_reason": "两者都可能调用工具，但 Terminal-Bench 以终端工程任务完成为主，tau3-Banking 以多轮用户交互和工具协同为主。",
    },
}
# Frozen V2 top-five order.  This is a guard against a validation-only
# experiment accidentally changing the production scoring path.
FROZEN_MAIN_TOP5 = {
    "问题一通用": ("Kimi K3 (max)", "Claude Opus 5 (max)", "Grok 4.6 (high)", "Claude Fable 5 (with fallback)", "Gemini 3.7 Flash (high)"),
    "科研长文本": ("Kimi K3 (max)", "Muse Spark 1.2 (xhigh)", "Gemini 3.7 Flash (high)", "Claude Opus 5 (max)", "Claude Fable 5 (with fallback)"),
    "大众日常对话": ("Grok 4.6 (high)", "Kimi K3 (max)", "Claude Opus 5 (max)", "Qwen3.8 Max", "Claude Fable 5 (with fallback)"),
    "计算机代码开发": ("Kimi K3 (max)", "Gemini 3.7 Flash (high)", "Claude Opus 5 (max)", "Claude Fable 5 (with fallback)", "GPT-5.6 Sol (max)"),
}

# Exact task-chain dependency matrices frozen in modeling/MODEL_SPEC_V2.md.
# Each scenario has five equally important tasks (p=1/5).
TASK_DEPENDENCY = {
    "科研长文本": [[1, 2, 2, 3, 0, 0, 1], [2, 2, 2, 3, 0, 0, 1], [3, 2, 2, 1, 1, 0, 0], [2, 2, 3, 2, 0, 0, 0], [1, 1, 2, 1, 0, 0, 2]],
    "大众日常对话": [[1, 1, 1, 0, 0, 0, 3], [1, 3, 3, 0, 0, 0, 1], [1, 1, 2, 1, 0, 0, 3], [2, 1, 1, 0, 0, 0, 2], [1, 1, 3, 0, 0, 0, 2]],
    "计算机代码开发": [[2, 1, 1, 1, 2, 1, 1], [2, 1, 1, 1, 3, 1, 0], [2, 1, 1, 2, 3, 2, 0], [3, 1, 2, 1, 3, 3, 0], [1, 0, 1, 1, 2, 3, 1]],
}
TASK_NAMES = {
    "科研长文本": ["信息定位", "跨文档综合", "科学推理", "证据核验", "报告组织"],
    "大众日常对话": ["意图理解", "事实问答", "多轮跟进", "规划推理", "答复核验"],
    "计算机代码开发": ["需求设计", "代码生成", "理解重构", "调试测试", "终端执行"],
}
SCENARIOS = list(TASK_DEPENDENCY)
SCENARIO_DEMAND = {
    scenario: {ability: float(np.mean(np.asarray(matrix, dtype=float)[:, j])) for j, ability in enumerate(ABILITIES)}
    for scenario, matrix in TASK_DEPENDENCY.items()
}
SCENARIO_INTENSITY = SCENARIO_DEMAND
CRITICAL_ABILITIES = {
    "科研长文本": ["C3", "C4", "C1"],
    "大众日常对话": ["C7", "C3", "C2"],
    "计算机代码开发": ["C5", "C1", "C6"],
}
SCENARIO_COLORS = {"科研长文本": "#1f77b4", "大众日常对话": "#d95f02", "计算机代码开发": "#2ca25f"}
WORKLOADS = {
    "科研长文本": {"input_tokens": 80_000, "output_tokens": 4_000, "latency_limit": 180.0},
    "大众日常对话": {"input_tokens": 2_000, "output_tokens": 800, "latency_limit": 30.0},
    "计算机代码开发": {"input_tokens": 20_000, "output_tokens": 4_000, "latency_limit": 90.0},
}
# Sensitivity grids are frozen in the V3 validation protocol.  They are kept
# separate from WORKLOADS so the latter continues to define the V2 medium
# workload used by the primary problem-three outputs.
LATENCY_THRESHOLDS = {
    "科研长文本": (120.0, 180.0, 240.0, 300.0),
    "大众日常对话": (20.0, 30.0, 45.0, 60.0),
    "计算机代码开发": (60.0, 90.0, 120.0, 180.0),
}
WORKLOAD_SENSITIVITY = {
    "科研长文本": {"light": (20_000, 2_000), "medium": (80_000, 4_000), "heavy": (160_000, 8_000)},
    "大众日常对话": {"light": (1_000, 300), "medium": (2_000, 800), "heavy": (8_000, 2_000)},
    "计算机代码开发": {"light": (5_000, 1_000), "medium": (20_000, 4_000), "heavy": (50_000, 8_000)},
}
CACHE_HIT_RATES = (0.0, 0.3, 0.6, 0.9)
V3_MONTE_CARLO_DRAWS = 5_000
V3_MONTE_CARLO_KAPPA = 100.0
V3_SEED = SEED + 303


def configure_plot_style() -> None:
    """Use a known Chinese font when available and keep figures printable."""
    candidates = ["Noto Sans SC", "Noto Sans CJK SC", "SimHei", "Microsoft YaHei", "DengXian"]
    installed = {f.name for f in fm.fontManager.ttflist}
    chosen = next((name for name in candidates if name in installed), None)
    if chosen:
        plt.rcParams["font.sans-serif"] = [chosen, "DejaVu Sans"]
    else:
        # The Windows image has SimHei installed, but this fallback makes the
        # pipeline portable to the team's Linux runner.
        for path in (Path("C:/Windows/Fonts/simhei.ttf"), Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc")):
            if path.exists():
                fm.fontManager.addfont(str(path))
                name = fm.FontProperties(fname=str(path)).get_name()
                plt.rcParams["font.sans-serif"] = [name, "DejaVu Sans"]
                break
    plt.rcParams.update({
        "axes.unicode_minus": False,
        "font.size": 9.5,
        "axes.titlesize": 11,
        "axes.labelsize": 9.5,
        "xtick.labelsize": 8,
        "ytick.labelsize": 8,
        "figure.dpi": 140,
        "savefig.dpi": 220,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "grid.alpha": 0.22,
    })


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def to_float(value: object) -> float | None:
    if value is None:
        return None
    text = str(value).strip()
    if text == "" or text.lower() in {"na", "nan", "null", "none"}:
        return None
    try:
        number = float(text)
        return number if math.isfinite(number) else None
    except ValueError:
        return None


def is_true(value: object) -> bool:
    return str(value).strip().lower() in {"true", "1", "yes"}


def write_csv(path: Path, rows: Iterable[Mapping[str, object]], fieldnames: Sequence[str] | None = None) -> None:
    rows = list(rows)
    if fieldnames is None:
        fieldnames = list(rows[0].keys()) if rows else []
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(fieldnames), extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key, "") for key in fieldnames})


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, default=float), encoding="utf-8")


def rank_percentile(values: Sequence[float], higher_is_better: bool = True) -> np.ndarray:
    arr = np.asarray(values, dtype=float)
    ranks = rankdata(arr if higher_is_better else -arr, method="average")
    if len(arr) <= 1:
        return np.full(len(arr), 0.5)
    return (ranks - 1.0) / (len(arr) - 1.0)


def minmax(values: np.ndarray) -> np.ndarray:
    arr = np.asarray(values, dtype=float)
    lo = float(np.min(arr))
    hi = float(np.max(arr))
    if hi - lo <= 1e-12:
        return np.full(arr.shape, 0.5)
    return (arr - lo) / (hi - lo)


def robust_z(values: np.ndarray) -> np.ndarray:
    """Robust centre/scale transform using median and IQR.

    This is used only as a structural standardisation control.  The main
    V2 ranking remains the frozen quantile transform.  The returned values are
    the raw robust z scores; they are not clipped or remapped, so the formula
    remains exactly (x-median)/IQR.
    """
    arr = np.asarray(values, dtype=float)
    med = float(np.median(arr))
    q1, q3 = np.percentile(arr, [25, 75])
    iqr = float(q3 - q1)
    if iqr <= 1e-12:
        return np.zeros(arr.shape)
    return (arr - med) / iqr


def pearson_matrix(matrix: np.ndarray) -> np.ndarray:
    matrix = np.asarray(matrix, dtype=float)
    if matrix.shape[1] == 1:
        return np.ones((1, 1))
    out = np.eye(matrix.shape[1])
    for i in range(matrix.shape[1]):
        for j in range(i):
            xi, xj = matrix[:, i], matrix[:, j]
            if np.std(xi) <= 1e-12 or np.std(xj) <= 1e-12:
                value = 0.0
            else:
                value = float(np.corrcoef(xi, xj)[0, 1])
            out[i, j] = out[j, i] = value
    return out


def orient_value(row: Mapping[str, object], indicator: Mapping[str, str]) -> float | None:
    value = to_float(row.get(indicator["source"]))
    if value is None:
        return None
    return value if indicator["direction"] == "benefit" else -value


def make_panel(
    names: Sequence[str], score_by_model: Mapping[str, Mapping[str, float]], api_by_model: Mapping[str, Mapping[str, str]],
) -> tuple[np.ndarray, dict[str, dict[str, float]], list[dict[str, object]]]:
    raw = np.empty((len(names), len(INDICATORS)), dtype=float)
    for i, name in enumerate(names):
        for j, indicator in enumerate(INDICATORS):
            source = indicator["source"]
            value = score_by_model[name].get(source)
            if value is None:
                raise ValueError(f"核心面板存在缺失值: {name} / {indicator['id']}")
            raw[i, j] = value if indicator["direction"] == "benefit" else -value
    return raw, {}, []


def analyze_scores(raw: np.ndarray, names: Sequence[str], normalization: str = "quantile") -> dict[str, object]:
    oriented = np.asarray(raw, dtype=float)
    if normalization == "quantile":
        z = np.column_stack([rank_percentile(oriented[:, j], higher_is_better=True) for j in range(oriented.shape[1])])
    elif normalization == "minmax":
        z = np.column_stack([minmax(oriented[:, j]) for j in range(oriented.shape[1])])
    elif normalization == "robust-z":
        z = np.column_stack([robust_z(oriented[:, j]) for j in range(oriented.shape[1])])
    else:
        raise ValueError(normalization)
    # Transparent mapping: C1 is the equal average of HLE and GPQA; every
    # other quality dimension is a single observed benchmark.  Speed and E2E
    # are deliberately absent from the quality matrix.
    q_by_ability = {
        ability: np.full(sum(item["ability"] == ability for item in INDICATORS), 1.0 / sum(item["ability"] == ability for item in INDICATORS))
        for ability in ABILITIES
    }
    ability_scores = np.column_stack([
        np.sum(z[:, [j for j, item in enumerate(INDICATORS) if item["ability"] == ability]] * q_by_ability[ability][None, :], axis=1)
        for ability in ABILITIES
    ])
    generic_weights = np.full(len(ABILITIES), 1.0 / len(ABILITIES))
    scenario_weights = {scenario: normalize_weights([SCENARIO_DEMAND[scenario][ability] for ability in ABILITIES]) for scenario in SCENARIOS}
    all_weights = {"问题一通用": generic_weights, **scenario_weights}
    score_tables = {key: ability_scores @ np.asarray(weights, dtype=float) for key, weights in all_weights.items()}
    rank_tables = {key: rankdata(-score, method="average") for key, score in score_tables.items()}
    eligibility = {
        scenario: {theta: np.all(ability_scores[:, [ABILITIES.index(a) for a in CRITICAL_ABILITIES[scenario]]] >= theta, axis=1) for theta in (0.20, 0.25, 0.30)}
        for scenario in SCENARIOS
    }
    return {
        "oriented": oriented,
        "z": z,
        "q_by_ability": q_by_ability,
        "ability_scores": ability_scores,
        "weights": all_weights,
        "scores": score_tables,
        "ranks": rank_tables,
        "eligibility": eligibility,
        "normalization": normalization,
        "names": list(names),
    }


def normalize_weights(values: Sequence[float]) -> np.ndarray:
    arr = np.asarray(values, dtype=float)
    total = float(np.sum(arr))
    return arr / total if total else np.full(len(arr), 1.0 / len(arr))


def rank_rows(names: Sequence[str], scores: Mapping[str, np.ndarray], ranks: Mapping[str, np.ndarray]) -> list[dict[str, object]]:
    rows = []
    for i, name in enumerate(names):
        row: dict[str, object] = {"model_name": name}
        for key, values in scores.items():
            row[f"{key}_score"] = round(float(values[i]), 8)
            row[f"{key}_rank"] = int(round(float(ranks[key][i])))
        rows.append(row)
    return rows


def load_data() -> tuple[list[str], dict[str, dict[str, float]], dict[str, dict[str, str]], list[dict[str, str]]]:
    # Use the formal frozen delivery tables.  The legacy chart-normalized
    # files remain useful as a collection audit but are not an input here.
    score_rows = read_csv(DATA_DIR / "scores_long.csv")
    model_rows = read_csv(DATA_DIR / "models.csv")
    api_rows = read_csv(DATA_DIR / "engineering_cost.csv")
    model_by_id = {row["model_id"]: row for row in model_rows}
    api_by_model = {row["model_name_display"]: row for row in api_rows}
    score_by_model: dict[str, dict[str, float]] = defaultdict(dict)
    for row in score_rows:
        value = to_float(row.get("score"))
        if value is not None:
            model_meta = model_by_id.get(row.get("model_id", ""))
            display_name = model_meta["model_name_display"] if model_meta else row.get("model_name_display", "")
            score_by_model[display_name][row["benchmark_display_name"]] = value
    required_scores = [x["source"] for x in INDICATORS]
    # The C1/C2 panel is the complete public Benchmark intersection, not the
    # smaller engineering intersection.  Engineering fields are checked only
    # when building the problem-three 20-configuration sample.
    core_names = [row["model_name_display"] for row in model_rows if all(source in score_by_model[row["model_name_display"]] for source in required_scores)]
    if len(core_names) != 27:
        raise ValueError(f"二版质量主面板应为 27 个配置，实际 {len(core_names)} 个")
    return core_names, score_by_model, api_by_model, score_rows


def write_core_outputs(names: Sequence[str], raw: np.ndarray, analysis: Mapping[str, object], api_by_model: Mapping[str, Mapping[str, str]]) -> None:
    write_csv(RESULTS / "core_observations.csv", [
        {"model_name": name, **{INDICATORS[j]["id"]: round(float(raw[i, j] if INDICATORS[j]["direction"] == "benefit" else -raw[i, j]), 8) for j in range(len(INDICATORS))}}
        for i, name in enumerate(names)
    ])
    write_csv(RESULTS / "standardized_scores.csv", [
        {"model_name": name, "normalization": analysis["normalization"], **{INDICATORS[j]["id"]: round(float(analysis["z"][i, j]), 8) for j in range(len(INDICATORS))}}
        for i, name in enumerate(names)
    ])
    mapping_rows = []
    for ability, q in analysis["q_by_ability"].items():
        inds = [item for item in INDICATORS if item["ability"] == ability]
        for item, weight in zip(inds, q):
            rule = "C1 中 HLE/GPQA 等权融合；其余维度按单项观测直接映射" if ability == "C1" else "单项观测直接映射"
            mapping_rows.append({"ability": ability, "ability_label": ABILITY_LABELS[ability], "indicator": item["id"], "indicator_label": item["label"], "within_ability_weight": round(float(weight), 8), "n_within_ability": len(inds), "rule": rule})
    write_csv(RESULTS / "quality_mapping.csv", mapping_rows)
    ability_rows = []
    for i, name in enumerate(names):
        row = {"model_name": name}
        for j, ability in enumerate(ABILITIES):
            row[ability] = round(float(analysis["ability_scores"][i, j]), 8)
        ability_rows.append(row)
    write_csv(RESULTS / "ability_scores.csv", ability_rows)
    write_csv(RESULTS / "rankings.csv", rank_rows(names, analysis["scores"], analysis["ranks"]))
    write_csv(RESULTS / "scenario_weights.csv", [{"weight_set": key, "ability": ability, "ability_label": ABILITY_LABELS[ability], "weight": round(float(value[j]), 8), "source": "通用等权" if key == "问题一通用" else "任务链需求乘通用权重后归一化"} for key, value in analysis["weights"].items() for j, ability in enumerate(ABILITIES)])
    write_csv(RESULTS / "task_chain_demands.csv", [{"scenario": scenario, "ability": ability, "ability_label": ABILITY_LABELS[ability], "demand": round(float(SCENARIO_DEMAND[scenario][ability]), 8), "task_importance": 0.2, "dependency_scale": "0-3"} for scenario in SCENARIOS for ability in ABILITIES])
    write_csv(RESULTS / "scenario_task_matrix.csv", [
        {"scenario": scenario, "task_id": task_index + 1, "task_name": TASK_NAMES[scenario][task_index], "task_importance": 0.2, **{ability: int(value) for ability, value in zip(ABILITIES, dependency)}}
        for scenario in SCENARIOS
        for task_index, dependency in enumerate(TASK_DEPENDENCY[scenario])
    ])
    write_json(RESULTS / "scenario_weights.json", {key: [round(float(x), 8) for x in value] for key, value in analysis["weights"].items()})
    write_csv(RESULTS / "eligibility_thresholds.csv", [{"scenario": scenario, "theta": theta, "critical_abilities": ";".join(CRITICAL_ABILITIES[scenario]), "eligible_count": int(np.sum(mask)), "eligible_rate": round(float(np.mean(mask)), 8), "raw_ranking_rule": "场景综合得分 S_is；相对短板资格 I_is(theta) 仅标记可推荐集合"} for scenario, by_theta in analysis["eligibility"].items() for theta, mask in by_theta.items()])
    model_meta = []
    for name in names:
        api = api_by_model[name]
        model_meta.append({"model_name": name, "creator": api.get("model_creator", ""), "release_date": api.get("release_date", ""), "api_model_slug": api.get("api_model_slug", "")})
    write_csv(RESULTS / "core_models.csv", model_meta)


def correlation_outputs(names: Sequence[str], raw: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Report quality-indicator rank association without automatic deletion.

    All eight indicators already point in the benefit direction.  Positive
    rho>=.85 is only a redundancy warning; the clustering distance is exactly
    d=1-rho, as fixed in MODEL_SPEC_V2.md.
    """
    diagnostic_raw = np.asarray(raw, dtype=float)
    p = diagnostic_raw.shape[1]
    rho = np.eye(p)
    for i in range(p):
        for j in range(i):
            value, _ = spearmanr(diagnostic_raw[:, i], diagnostic_raw[:, j])
            rho[i, j] = rho[j, i] = float(value) if np.isfinite(value) else 0.0
    write_csv(RESULTS / "spearman_matrix.csv", [{"indicator": INDICATORS[i]["id"], **{INDICATORS[j]["id"]: round(float(rho[i, j]), 8) for j in range(p)}} for i in range(p)])
    corr_rows = []
    for i in range(p):
        for j in range(i + 1, p):
            value = float(rho[i, j])
            corr_rows.append({"indicator_i": INDICATORS[i]["id"], "indicator_j": INDICATORS[j]["id"], "ability_i": INDICATORS[i]["ability"], "ability_j": INDICATORS[j]["ability"], "spearman_rho": round(value, 8), "overlap_n": len(names), "redundancy_warning": bool(value >= 0.85), "distance_1_minus_rho": round(1.0 - value, 8), "delete_from_main": False, "semantic_reason": "相关性仅作冗余诊断；是否删除还需构念、覆盖率与可比性审核"})
    write_csv(RESULTS / "spearman_pairs.csv", corr_rows)
    high_corr_rows = []
    for i in range(p):
        for j in range(i + 1, p):
            value = float(rho[i, j])
            if value < 0.85:
                continue
            item_a, item_b = INDICATORS[i], INDICATORS[j]
            review = high_corr_review(item_a, item_b)
            high_corr_rows.append({
                "benchmark_a": item_a["id"],
                "benchmark_b": item_b["id"],
                "benchmark_a_label": item_a["label"],
                "benchmark_b_label": item_b["label"],
                "spearman_rho": round(value, 8),
                "overlap_n": len(names),
                "construct_a": ABILITY_LABELS[item_a["ability"]],
                "construct_b": ABILITY_LABELS[item_b["ability"]],
                "constructs_highly_overlapping": review["constructs_highly_overlapping"],
                "substantive_redundancy": review["substantive_redundancy"],
                "final_treatment": review["final_treatment"],
                "treatment_reason": review["treatment_reason"],
            })
    write_csv(RESULTS / "all_high_corr_pairs.csv", high_corr_rows)
    distance = np.clip(1.0 - rho, 0.0, 2.0)
    linkage_matrix = linkage(squareform(distance, checks=False), method="average")
    labels = fcluster(linkage_matrix, t=1.0 - 0.85, criterion="distance")
    write_csv(RESULTS / "indicator_clusters.csv", [{"indicator": item["id"], "label": item["label"], "ability": item["ability"], "average_linkage_cluster_at_rho_085": int(labels[i]), "main_status": "保留（仅诊断）"} for i, item in enumerate(INDICATORS)])
    write_json(RESULTS / "correlation_metadata.json", {
        "threshold": 0.85,
        "redundancy_rule": "rho>=0.85",
        "distance": "d=1-rho",
        "linkage_method": "average",
        "linkage_reason": "average linkage 兼顾簇间整体距离，较少受到单一最近点影响，适合作为 Benchmark 相关结构的诊断工具",
        "direction_rule": "all eight quality indicators are benefit-oriented",
        "deletion_rule": "no automatic deletion from correlation alone",
        "review_rule": "statistical association + task construct + coverage + discrimination + source reliability",
        "high_corr_pair_count": len(high_corr_rows),
    })
    return rho, linkage_matrix


def kimi_outputs(names: Sequence[str], analysis: Mapping[str, object]) -> None:
    if "Kimi K3 (max)" not in names:
        raise ValueError("Kimi K3 (max) 未进入主样本")
    ki = list(names).index("Kimi K3 (max)")
    abilities = np.asarray(analysis["ability_scores"])
    mean = np.mean(abilities, axis=0)
    median = np.median(abilities, axis=0)
    generic_w = np.asarray(analysis["weights"]["问题一通用"])
    # ``top_model`` in the summary is the overall balanced-score leader, but
    # the contribution table compares Kimi with the leader of *each ability*.
    # Reusing the overall index here silently made every ``top_model_score``
    # equal to Kimi whenever Kimi ranked first overall.
    overall_top_idx = int(np.argmax(analysis["scores"]["问题一通用"]))
    rows = []
    for j, ability in enumerate(ABILITIES):
        ability_top_idx = int(np.argmax(abilities[:, j]))
        rows.append({"ability": ability, "ability_label": ABILITY_LABELS[ability], "kimi_score": round(float(abilities[ki, j]), 8), "sample_mean": round(float(mean[j]), 8), "sample_median": round(float(median[j]), 8), "advantage_vs_mean": round(float(abilities[ki, j] - mean[j]), 8), "advantage_vs_median": round(float(abilities[ki, j] - median[j]), 8), "generic_weight": round(float(generic_w[j]), 8), "generic_contribution": round(float(generic_w[j] * abilities[ki, j]), 8), "top_model_name": names[ability_top_idx], "top_model_score": round(float(abilities[ability_top_idx, j]), 8), "gap_to_top": round(float(abilities[ability_top_idx, j] - abilities[ki, j]), 8)})
    write_csv(RESULTS / "kimi_ability_contribution.csv", rows)
    write_json(RESULTS / "kimi_summary.json", {
        "model": "Kimi K3 (max)", "generic_rank": int(analysis["ranks"]["问题一通用"][ki]), "generic_score": float(analysis["scores"]["问题一通用"][ki]),
        "top_model": names[overall_top_idx], "top_score": float(analysis["scores"]["问题一通用"][overall_top_idx]), "score_gap": float(analysis["scores"]["问题一通用"][overall_top_idx] - analysis["scores"]["问题一通用"][ki]),
    })


def scenario_decomposition(names: Sequence[str], analysis: Mapping[str, object]) -> None:
    records = []
    scenarios = list(SCENARIO_INTENSITY)
    for a_i in range(len(scenarios)):
        for b_i in range(a_i + 1, len(scenarios)):
            a, b = scenarios[a_i], scenarios[b_i]
            delta_w = np.asarray(analysis["weights"][b]) - np.asarray(analysis["weights"][a])
            for i, name in enumerate(names):
                row = {"model_name": name, "from_scenario": a, "to_scenario": b}
                contributions = []
                for j, ability in enumerate(ABILITIES):
                    value = float(delta_w[j] * analysis["ability_scores"][i, j])
                    row[f"delta_{ability}"] = round(value, 8)
                    contributions.append(value)
                row["delta_total"] = round(float(np.sum(contributions)), 8)
                row["direct_score_difference"] = round(float(analysis["scores"][b][i] - analysis["scores"][a][i]), 8)
                row["rank_from"] = int(analysis["ranks"][a][i])
                row["rank_to"] = int(analysis["ranks"][b][i])
                records.append(row)
    write_csv(RESULTS / "scenario_decomposition.csv", records)


def pareto_frontier(rows: Sequence[Mapping[str, object]], performance_key: str, cost_key: str) -> list[dict[str, object]]:
    sorted_rows = sorted(rows, key=lambda row: (float(row[cost_key]), -float(row[performance_key])))
    best = -float("inf")
    frontier = []
    for row in sorted_rows:
        performance = float(row[performance_key])
        if performance > best + 1e-12:
            frontier.append(dict(row))
            best = performance
    return frontier


def budget_segments(rows: Sequence[Mapping[str, object]], score_key: str, cost_key: str, latency_key: str, latency_limit: float) -> list[dict[str, object]]:
    eligible = [row for row in rows if float(row[latency_key]) <= latency_limit]
    if not eligible:
        return [{"budget_lower_usd_per_1000": 0.0, "budget_upper_usd_per_1000": "inf", "recommended_model": "无可行模型", "score": "", "latency_seconds": "", "latency_limit": latency_limit, "status": "无可行模型"}]
    min_cost = min(float(row[cost_key]) for row in eligible)
    unique_costs = sorted({round(float(row[cost_key]), 10) for row in eligible})
    switches: list[tuple[float, Mapping[str, object]]] = []
    previous_model = None
    for cost in unique_costs:
        candidates = [row for row in eligible if float(row[cost_key]) <= cost + 1e-9]
        # At a tied cost, keep the highest-performance model.  This prevents
        # zero-width intervals such as [64,64) from entering the table.
        best_row = max(candidates, key=lambda row: (float(row[score_key]), -float(row[latency_key])))
        if best_row["model_name"] != previous_model:
            switches.append((cost, best_row))
            previous_model = best_row["model_name"]
    segments = []
    if min_cost > 1e-12:
        segments.append({"budget_lower_usd_per_1000": 0.0, "budget_upper_usd_per_1000": round(min_cost, 8), "recommended_model": "无可行模型", "score": "", "latency_seconds": "", "latency_limit": latency_limit, "status": "无可行模型"})
    for i, (start, row) in enumerate(switches):
        end = switches[i + 1][0] if i + 1 < len(switches) else float("inf")
        if end <= start + 1e-12:
            continue
        segments.append({"budget_lower_usd_per_1000": round(start, 8), "budget_upper_usd_per_1000": "inf" if math.isinf(end) else round(end, 8), "recommended_model": row["model_name"], "score": round(float(row[score_key]), 8), "latency_seconds": round(float(row[latency_key]), 8), "latency_limit": latency_limit})
    return segments


TOKEN_CHART_FILES = {
    "HLE": "hle-charts.json",
    "GPQA": "gpqa-diamond-charts.json",
    "LCR": "aa-lcr-charts.json",
    "SciCode": "scicode-charts.json",
    "tau3": "tau3-banking-charts.json",
    "Terminal": "terminalbench-v2-1-charts.json",
}


def parse_token_label(label: object) -> float | None:
    """Parse the compact labels used by the public Token Usage SVGs."""
    text = str(label).strip().replace(",", "")
    if not text:
        return None
    match = re.fullmatch(r"([0-9]+(?:\.[0-9]+)?)\s*([kK])?", text)
    if not match:
        return None
    number = float(match.group(1))
    if match.group(2):
        number *= 1000.0
    return number


def load_compute_proxy(names: Sequence[str]) -> dict[str, dict[str, object]]:
    """Build a transparent output-token burden proxy from public charts.

    The extraction script records SVG text in document order.  When a chart
    has exactly two label blocks of length n, the frozen transcription rule
    uses the last n labels as the total-token sequence.  Charts with extra
    blocks or a non-one-to-one label sequence are retained in the audit table
    but excluded from the primary proxy.  This is deliberately conservative:
    a token count is never guessed from a missing label or from another model.
    """
    tokens: dict[str, dict[str, float]] = {name: {} for name in names}
    source_rows = []
    audit_rows = []
    for benchmark, filename in TOKEN_CHART_FILES.items():
        path = RAW_DATA_DIR / filename
        if not path.exists():
            source_rows.append({"benchmark": benchmark, "source_file": str(path), "chart_index": 1, "n_models": "", "n_labels": "", "method": "file_missing", "reliable": False, "note": "原始图表文件不存在"})
            continue
        with path.open("r", encoding="utf-8-sig") as handle:
            payload = json.load(handle)
        charts = payload["charts"] if isinstance(payload, dict) else payload
        chart = next((item for item in charts if item.get("chart_index") == 1), None)
        if chart is None:
            source_rows.append({"benchmark": benchmark, "source_file": str(path.relative_to(ROOT)), "chart_index": 1, "n_models": "", "n_labels": "", "method": "chart_missing", "reliable": False, "note": "未找到 Token Usage 图"})
            continue
        model_list = [item.get("name", "").strip() for item in chart.get("models", [])]
        labels = list(chart.get("labels", []))
        n = len(model_list)
        method = "last_n_of_2n" if n > 0 and len(labels) == 2 * n else "unsupported_label_layout"
        reliable = method == "last_n_of_2n"
        values = [parse_token_label(label) for label in labels[-n:]] if n else []
        if reliable and (len(values) != n or any(value is None for value in values)):
            reliable = False
            method = "unparseable_last_n"
        matched = 0
        if reliable:
            for model, value in zip(model_list, values):
                if model in tokens and value is not None:
                    tokens[model][benchmark] = float(value)
                    matched += 1
            kimi_idx = model_list.index("Kimi K3 (max)") if "Kimi K3 (max)" in model_list else None
            audit_rows.append({
                "benchmark": benchmark, "first_model": model_list[0] if model_list else "", "first_tokens": float(values[0]) if values else "",
                "kimi_model": "Kimi K3 (max)", "kimi_tokens": float(values[kimi_idx]) if kimi_idx is not None else "",
                "last_model": model_list[-1] if model_list else "", "last_tokens": float(values[-1]) if values else "",
                "order_alignment_check": "通过：模型数组与最后n个标签按页面顺序配对", "spot_check_status": "程序核对首位/Kimi/末位；正文应附截图复核",
            })
        source_rows.append({
            "benchmark": benchmark, "source_file": str(path.relative_to(ROOT)), "chart_index": 1,
            "n_models": n, "n_labels": len(labels), "method": method, "reliable": reliable,
            "matched_core_models": matched, "total_label_sequence_used": "last n labels" if reliable else "none",
            "note": "两块等长序列，按冻结规则采用最后 n 个标签；其他版式不进入主代理" if reliable else "标签块数量不是 2n，未据此推断 total token",
        })
    write_csv(RESULTS / "compute_proxy_sources.csv", source_rows)
    write_csv(RESULTS / "compute_proxy_audit.csv", audit_rows)
    reliable_benchmarks = [row["benchmark"] for row in source_rows if row.get("reliable") in {True, "True"}]
    # Compute burden is an average over the reliably parsed benchmark charts;
    # all benchmark-level ranks are calculated only on their observed values.
    rank_by_benchmark: dict[str, dict[str, float]] = {}
    for benchmark in reliable_benchmarks:
        observed = {name: tokens[name][benchmark] for name in names if benchmark in tokens[name]}
        vals = np.asarray(list(observed.values()), dtype=float)
        ranks = rank_percentile(vals, higher_is_better=True)
        rank_by_benchmark[benchmark] = {name: float(rank) for name, rank in zip(observed, ranks)}
    proxy_rows = []
    for name in names:
        available = [tokens[name][benchmark] for benchmark in reliable_benchmarks if benchmark in tokens[name]]
        burden_ranks = [rank_by_benchmark[benchmark][name] for benchmark in reliable_benchmarks if name in rank_by_benchmark[benchmark]]
        proxy_rows.append({
            "model_name": name,
            "reliable_benchmark_count": len(available),
            "core_benchmark_coverage_over_8": len(available) / 8.0,
            "token_benchmark_names": ";".join(reliable_benchmarks),
            "compute_burden_tokens_mean": float(np.mean(available)) if available else "",
            "compute_burden_tokens_median": float(np.median(available)) if available else "",
            "compute_burden_percentile_mean": float(np.mean(burden_ranks)) if burden_ranks else "",
            "compute_efficiency_percentile_mean": float(1.0 - np.mean(burden_ranks)) if burden_ranks else "",
            **{f"tokens_{benchmark}": tokens[name].get(benchmark, "") for benchmark in TOKEN_CHART_FILES},
        })
    write_csv(RESULTS / "compute_proxy.csv", proxy_rows)
    # Sensitivity is explicit rather than hidden: compare the frozen last-n
    # transcription with the alternative sum of the two visible blocks only
    # for HLE/GPQA, whose chart structure is exactly 2n.
    sensitivity_rows = []
    for benchmark, filename in TOKEN_CHART_FILES.items():
        path = RAW_DATA_DIR / filename
        if not path.exists():
            continue
        with path.open("r", encoding="utf-8-sig") as handle:
            payload = json.load(handle)
        charts = payload["charts"] if isinstance(payload, dict) else payload
        chart = next((item for item in charts if item.get("chart_index") == 1), None)
        if chart is None:
            continue
        model_list = [item.get("name", "").strip() for item in chart.get("models", [])]
        labels = chart.get("labels", [])
        n = len(model_list)
        if n == 0 or len(labels) != 2 * n:
            continue
        first = [parse_token_label(v) for v in labels[:n]]
        last = [parse_token_label(v) for v in labels[-n:]]
        if any(v is None for v in first + last):
            continue
        for model, frozen, alt in zip(model_list, last, np.asarray(first) + np.asarray(last)):
            if model in tokens:
                sensitivity_rows.append({"model_name": model, "benchmark": benchmark, "frozen_last_n_tokens": float(frozen), "alternative_first_plus_last_tokens": float(alt), "difference_tokens": float(alt - frozen), "layout": "2n"})
    write_csv(RESULTS / "compute_proxy_sensitivity.csv", sensitivity_rows)
    return {row["model_name"]: row for row in proxy_rows}


def multicriteria_pareto(rows: Sequence[Mapping[str, object]], performance_key: str = "performance", cost_key: str = "cost_usd_per_1000_tasks", latency_key: str = "latency_seconds", compute_key: str = "compute_burden_tokens_mean") -> list[dict[str, object]]:
    """Pareto set for performance up, fee/latency/compute burden down."""
    out = []
    for row in rows:
        p, c, l, q = float(row[performance_key]), float(row[cost_key]), float(row[latency_key]), to_float(row.get(compute_key))
        if q is None:
            continue
        dominated = False
        for other in rows:
            if other is row:
                continue
            op, oc, ol, oq = float(other[performance_key]), float(other[cost_key]), float(other[latency_key]), to_float(other.get(compute_key))
            if oq is None:
                continue
            no_worse = op >= p - 1e-12 and oc <= c + 1e-12 and ol <= l + 1e-12 and oq <= q + 1e-12
            strict = op > p + 1e-12 or oc < c - 1e-12 or ol < l - 1e-12 or oq < q - 1e-12
            if no_worse and strict:
                dominated = True
                break
        if not dominated:
            out.append(dict(row))
    return out


def quality_cost_latency_pareto(
    rows: Sequence[Mapping[str, object]],
    performance_key: str = "quality_score",
    cost_key: str = "cost_usd_per_1000_tasks",
    latency_key: str = "latency_seconds",
) -> list[dict[str, object]]:
    """Primary engineering Pareto set: S_is up, fee and E2E proxy down.

    The output-token burden proxy is intentionally not part of this primary
    frontier.  It is reported only by the separate extended engineering
    frontier so that the paper's problem-three decision model does not turn a partial
    proxy into a hard deployment criterion.  ``latency_key`` is measured under
    a unified evaluation protocol and is an engineering-efficiency proxy, not
    the response time under any scenario workload used in this paper.
    """
    out: list[dict[str, object]] = []
    for row in rows:
        p = float(row[performance_key])
        c = float(row[cost_key])
        l = float(row[latency_key])
        dominated = False
        for other in rows:
            if other is row:
                continue
            op = float(other[performance_key])
            oc = float(other[cost_key])
            ol = float(other[latency_key])
            no_worse = op >= p - 1e-12 and oc <= c + 1e-12 and ol <= l + 1e-12
            strict = op > p + 1e-12 or oc < c - 1e-12 or ol < l - 1e-12
            if no_worse and strict:
                dominated = True
                break
        if not dominated:
            out.append(dict(row))
    return out


def q3_outputs(names: Sequence[str], analysis: Mapping[str, object], api_by_model: Mapping[str, Mapping[str, str]], compute_proxy: Mapping[str, Mapping[str, object]]) -> dict[str, list[dict[str, object]]]:
    q3_names = [name for name in names if name in api_by_model and to_float(api_by_model[name].get("input_price_usd_per_1m_tokens")) is not None and to_float(api_by_model[name].get("output_price_usd_per_1m_tokens")) is not None and to_float(api_by_model[name].get("input_price_usd_per_1m_tokens")) > 0 and to_float(api_by_model[name].get("output_price_usd_per_1m_tokens")) > 0 and to_float(api_by_model[name].get("e2e_seconds")) is not None and to_float(api_by_model[name].get("output_speed_tokens_per_second")) is not None]
    if len(q3_names) != 20 or "Nemotron 3 Super" not in q3_names or "Command A+" in q3_names:
        raise ValueError(f"问题三应为正单价且工程字段完整的 20 个配置，实际 {len(q3_names)}")
    scenario_rows: dict[str, list[dict[str, object]]] = {}
    all_cost_rows = []
    for scenario, workload in WORKLOADS.items():
        rows = []
        gate = np.asarray(analysis["eligibility"][scenario][0.25], dtype=bool)
        for name in q3_names:
            api = api_by_model[name]
            pin = to_float(api.get("input_price_usd_per_1m_tokens"))
            pout = to_float(api.get("output_price_usd_per_1m_tokens"))
            if pin is None or pout is None or pin <= 0 or pout <= 0:
                raise ValueError(f"问题三正价样本异常: {name} / {pin} / {pout}")
            model_index = list(names).index(name)
            # h=0 is frozen; cache prices intentionally do not enter this expression.
            cost = 1000.0 * (workload["input_tokens"] * pin + workload["output_tokens"] * pout) / 1_000_000.0
            row = {
                "model_name": name,
                "scenario": scenario,
                "performance": float(analysis["scores"][scenario][model_index]),
                "quality_score": float(analysis["scores"][scenario][model_index]),
                "raw_quality_score": float(analysis["scores"][scenario][model_index]),
                "raw_rank": int(analysis["ranks"][scenario][model_index]),
                "eligible_theta_025": bool(gate[model_index]),
                "cost_usd_per_1000_tasks": cost,
                "latency_seconds": to_float(api.get("e2e_seconds")),
                "speed_tokens_per_second": to_float(api.get("output_speed_tokens_per_second")),
                "input_tokens_per_task": workload["input_tokens"], "output_tokens_per_task": workload["output_tokens"],
                "h_cache": 0.0, "input_price_usd_per_1m_tokens": pin, "output_price_usd_per_1m_tokens": pout,
                "cost_field_note": "token prices only; AA Cost per Intelligence Index Task is not multiplied",
                "compute_burden_tokens_mean": compute_proxy.get(name, {}).get("compute_burden_tokens_mean", ""),
                "compute_burden_percentile_mean": compute_proxy.get(name, {}).get("compute_burden_percentile_mean", ""),
                "compute_proxy_coverage_over_8": compute_proxy.get(name, {}).get("core_benchmark_coverage_over_8", ""),
            }
            rows.append(row)
            all_cost_rows.append(row)
        scenario_rows[scenario] = rows
        # The engineering panel remains the complete positive-price 20-model
        # panel, but deployment Pareto and budget paths operate only on the
        # I_is(0.25) relative-shortfall eligibility subset.  S_is remains the
        # scenario ranking variable; the gate only marks recommendability.
        eligible_rows = [row for row in rows if row["eligible_theta_025"]]
        frontier = pareto_frontier(eligible_rows, "quality_score", "cost_usd_per_1000_tasks")
        for row in frontier:
            row["pareto"] = True
        frontier_names = {row["model_name"] for row in frontier}
        quality_latency_frontier = quality_cost_latency_pareto(eligible_rows)
        quality_latency_names = {row["model_name"] for row in quality_latency_frontier}
        multi_frontier = multicriteria_pareto(eligible_rows)
        multi_frontier_names = {row["model_name"] for row in multi_frontier}
        for row in rows:
            row["pareto"] = row["model_name"] in frontier_names
            row["pareto_quality_cost_latency"] = row["model_name"] in quality_latency_names
            row["pareto_multi_performance_fee_latency_compute"] = row["model_name"] in multi_frontier_names
        segments = budget_segments(eligible_rows, "quality_score", "cost_usd_per_1000_tasks", "latency_seconds", workload["latency_limit"])
        write_csv(RESULTS / f"q3_budget_segments_{scenario}.csv", segments)
        write_csv(RESULTS / f"q3_costs_{scenario}.csv", rows)
        write_csv(RESULTS / f"q3_pareto_{scenario}.csv", frontier)
        write_csv(RESULTS / f"q3_pareto_quality_cost_latency_{scenario}.csv", quality_latency_frontier)
        write_csv(RESULTS / f"q3_pareto_multicriteria_{scenario}.csv", multi_frontier)
    write_csv(RESULTS / "q3_costs_long.csv", all_cost_rows)
    return scenario_rows


def fit_models(x: np.ndarray, y: np.ndarray) -> dict[str, dict[str, object]]:
    """Fit the five prespecified curves and evaluate LOOCV RMSE/AICc."""
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    eps = max(float(np.min(x)) * 1e-6, 1e-8)

    def linear_fit(xx: np.ndarray, yy: np.ndarray) -> tuple[Callable[[np.ndarray], np.ndarray], int, dict[str, float]]:
        coef = np.linalg.lstsq(np.column_stack([np.ones(len(xx)), xx]), yy, rcond=None)[0]
        return lambda v: coef[0] + coef[1] * np.asarray(v), 2, {"a": float(coef[0]), "b": float(coef[1])}

    def log_fit(xx: np.ndarray, yy: np.ndarray) -> tuple[Callable[[np.ndarray], np.ndarray], int, dict[str, float]]:
        coef = np.linalg.lstsq(np.column_stack([np.ones(len(xx)), np.log(xx + eps)]), yy, rcond=None)[0]
        return lambda v: coef[0] + coef[1] * np.log(np.asarray(v) + eps), 2, {"a": float(coef[0]), "b": float(coef[1]), "eps": eps}

    def power_fit(xx: np.ndarray, yy: np.ndarray) -> tuple[Callable[[np.ndarray], np.ndarray], int, dict[str, float]]:
        safe_y = np.maximum(yy, 1e-8)
        coef = np.linalg.lstsq(np.column_stack([np.ones(len(xx)), np.log(xx + eps)]), np.log(safe_y), rcond=None)[0]
        a, b = float(np.exp(coef[0])), float(coef[1])
        return lambda v: a * np.power(np.asarray(v) + eps, b), 2, {"a": a, "b": b, "eps": eps}

    def sat_fn(v: np.ndarray, a: float, b: float, tau: float) -> np.ndarray:
        return a - b * np.exp(-np.asarray(v) / max(tau, 1e-8))

    def saturation_fit(xx: np.ndarray, yy: np.ndarray) -> tuple[Callable[[np.ndarray], np.ndarray], int, dict[str, float]]:
        p0 = [float(np.max(yy)), float(np.max(yy) - np.min(yy)), max(float(np.median(xx)), 1e-4)]
        bound_lo = [-2.0, -2.0, 1e-8]
        bound_hi = [2.0, 4.0, max(float(np.max(xx) * 100.0), 1.0)]
        params, _ = curve_fit(sat_fn, xx, yy, p0=p0, bounds=(bound_lo, bound_hi), maxfev=20_000)
        return lambda v: sat_fn(np.asarray(v), *params), 3, {"a": float(params[0]), "b": float(params[1]), "tau": float(params[2])}

    def breakpoint_fit(xx: np.ndarray, yy: np.ndarray) -> tuple[Callable[[np.ndarray], np.ndarray], int, dict[str, float]]:
        candidates = np.unique(np.quantile(xx, np.linspace(0.15, 0.85, 15)))
        best = None
        for knot in candidates:
            design = np.column_stack([np.ones(len(xx)), xx, np.maximum(0.0, xx - knot)])
            coef = np.linalg.lstsq(design, yy, rcond=None)[0]
            resid = yy - design @ coef
            rss = float(np.sum(resid * resid))
            if best is None or rss < best[0]:
                best = (rss, float(knot), coef)
        if best is None:
            raise ValueError("断点候选为空")
        _, knot, coef = best
        return lambda v: np.column_stack([np.ones(len(np.asarray(v))), np.asarray(v), np.maximum(0.0, np.asarray(v) - knot)]) @ coef, 4, {"a": float(coef[0]), "b1": float(coef[1]), "b2_change": float(coef[2]), "knot": knot}

    fitters: dict[str, Callable[[np.ndarray, np.ndarray], tuple[Callable[[np.ndarray], np.ndarray], int, dict[str, float]]]] = {
        "线性": linear_fit, "对数": log_fit, "幂函数": power_fit, "饱和": saturation_fit, "单断点": breakpoint_fit,
    }
    outputs: dict[str, dict[str, object]] = {}
    n = len(x)
    for name, fitter in fitters.items():
        try:
            pred_fn, p, params = fitter(x, y)
            pred = np.asarray(pred_fn(x), dtype=float)
            residual = y - pred
            rss = float(np.sum(residual * residual))
            aicc = n * math.log(max(rss / n, 1e-12)) + 2 * p + (2 * p * (p + 1) / max(n - p - 1, 1))
            loocv_errors = []
            for holdout in range(n):
                mask = np.ones(n, dtype=bool)
                mask[holdout] = False
                try:
                    fold_fn, _, _ = fitter(x[mask], y[mask])
                    loocv_errors.append(float(y[holdout] - fold_fn(np.asarray([x[holdout]]))[0]))
                except Exception:
                    loocv_errors.append(float("nan"))
            valid = np.asarray(loocv_errors, dtype=float)
            cv_rmse = float(np.sqrt(np.nanmean(valid * valid))) if np.any(np.isfinite(valid)) else float("inf")
            outputs[name] = {"params": params, "n_params": p, "pred": pred, "residual": residual, "rss": rss, "aicc": float(aicc), "loocv_rmse": cv_rmse}
        except Exception as exc:
            outputs[name] = {"params": {}, "n_params": 0, "pred": np.full(n, np.nan), "residual": np.full(n, np.nan), "rss": np.nan, "aicc": np.inf, "loocv_rmse": np.inf, "error": str(exc)}
    return outputs


def cost_fit_outputs(scenario_rows: Mapping[str, Sequence[Mapping[str, object]]]) -> None:
    summary = []
    point_rows = []
    for scenario, rows in scenario_rows.items():
        # Cost-performance curves are an engineering extension of the hard
        # gate, so non-recommendable quality configurations do not determine
        # the selected curve or its budget interpretation.
        rows = [row for row in rows if row.get("eligible_theta_025") in {True, "True"}]
        if len(rows) < 3:
            raise ValueError(f"{scenario} I_is(0.25) 相对短板资格样本不足以拟合成本曲线: {len(rows)}")
        x = np.asarray([float(row["cost_usd_per_1000_tasks"]) for row in rows])
        y = np.asarray([float(row["performance"]) for row in rows])
        fits = fit_models(x, y)
        best = min(fits, key=lambda name: (float(fits[name]["loocv_rmse"]), float(fits[name]["aicc"])))
        rank_corr, rank_p = spearmanr(x, y)
        for model, result in fits.items():
            tss = float(np.sum((y - np.mean(y)) ** 2))
            r2 = float(1.0 - result["rss"] / tss) if tss > 1e-12 and np.isfinite(result["rss"]) else float("nan")
            p = int(result["n_params"])
            adjusted_r2 = float(1.0 - (1.0 - r2) * (len(y) - 1) / max(len(y) - p - 1, 1)) if np.isfinite(r2) else float("nan")
            params = result.get("params", {})
            if model in {"线性", "对数", "幂函数"}:
                direction = {"slope": float(params.get("b", float("nan")))}
            elif model == "饱和":
                direction = {"initial_slope_sign": float(np.sign(params.get("b", float("nan")))), "tau": float(params.get("tau", float("nan")))}
            else:
                direction = {"slope_before_knot": float(params.get("b1", float("nan"))), "slope_change_after_knot": float(params.get("b2_change", float("nan"))), "slope_after_knot": float(params.get("b1", float("nan")) + params.get("b2_change", float("nan")))}
            row = {"scenario": scenario, "model": model, "loocv_rmse": result["loocv_rmse"], "aicc": result["aicc"], "rss": result["rss"], "r2": r2, "adjusted_r2": adjusted_r2, "spearman_rho_cost_performance": float(rank_corr), "spearman_p": float(rank_p), "parameter_directions": json.dumps(direction, ensure_ascii=False), "n_params": result["n_params"], "selected": model == best, "error": result.get("error", ""), "params": json.dumps(result.get("params", {}), ensure_ascii=False)}
            summary.append(row)
            if np.all(np.isfinite(result["pred"])):
                for item, pred, resid in zip(rows, result["pred"], result["residual"]):
                    point_rows.append({"scenario": scenario, "model": model, "model_name": item["model_name"], "cost_usd_per_1000_tasks": item["cost_usd_per_1000_tasks"], "actual_performance": item["performance"], "fitted_performance": float(pred), "residual": float(resid), "selected": model == best})
        write_json(RESULTS / f"q3_fit_{scenario}.json", {name: {key: value for key, value in result.items() if key not in {"pred", "residual"}} for name, result in fits.items()})
        for row in summary[-len(fits):]:
            row["selected_model"] = best
    write_csv(RESULTS / "q3_fit_summary.csv", summary)
    write_csv(RESULTS / "q3_fit_points.csv", point_rows)


def leave_one_outputs(names: Sequence[str], raw: np.ndarray, baseline: Mapping[str, object]) -> None:
    base_rank = np.asarray(baseline["ranks"]["问题一通用"], dtype=float)
    base_quality = np.asarray(baseline["z"], dtype=float)
    rows = []
    summary = []
    kim_idx = list(names).index("Kimi K3 (max)")
    for drop_j, dropped in enumerate(INDICATORS):
        keep = [j for j in range(raw.shape[1]) if j != drop_j]
        reduced_indicators = [INDICATORS[j] for j in keep]
        ability_mat = []
        present = []
        for ability in ABILITIES:
            idx = [j for j, item in enumerate(reduced_indicators) if item["ability"] == ability]
            present.append(bool(idx))
            ability_mat.append(np.mean(base_quality[:, [keep[j] for j in idx]], axis=1) if idx else np.zeros(len(names)))
        ability_mat = np.column_stack(ability_mat)
        weights = np.full(len(ABILITIES), 1.0 / len(ABILITIES))
        weights[~np.asarray(present, dtype=bool)] = 0.0
        weights = normalize_weights(weights)
        score = ability_mat @ weights
        ranks = rankdata(-score, method="average")
        tau = float(kendalltau(base_rank, ranks).statistic)
        summary.append({"dropped_benchmark": dropped["id"], "dropped_label": dropped["label"], "affected_ability": dropped["ability"] if len([item for item in INDICATORS if item["ability"] == dropped["ability"]]) == 1 else "C1由另一指标承接", "top_model": names[int(np.argmin(ranks))], "kimi_rank": int(ranks[kim_idx]), "kendall_tau_vs_baseline": tau, "rank_changed_count": int(np.sum(ranks != base_rank))})
        for i, name in enumerate(names):
            rows.append({"dropped_indicator": dropped["id"], "dropped_label": dropped["label"], "model_name": name, "rank": int(ranks[i]), "baseline_rank": int(base_rank[i]), "rank_change": int(ranks[i] - base_rank[i]), "kendall_tau_vs_baseline": tau})
    write_csv(RESULTS / "robustness_leave_one_indicator.csv", rows)
    write_csv(RESULTS / "robustness_leave_one_indicator_summary.csv", summary)
    ability_summary = []
    ability_detail = []
    for drop_idx, ability in enumerate(ABILITIES):
        keep = np.ones(len(ABILITIES), dtype=bool)
        keep[drop_idx] = False
        weights = normalize_weights(np.where(keep, 1.0, 0.0))
        score = np.asarray(baseline["ability_scores"]) @ weights
        ranks = rankdata(-score, method="average")
        ability_summary.append({"dropped_ability": ability, "ability_label": ABILITY_LABELS[ability], "scenario": "通用", "top_model": names[int(np.argmin(ranks))], "kimi_rank": int(ranks[kim_idx]), "kendall_tau_vs_baseline": float(kendalltau(base_rank, ranks).statistic), "rank_changed_count": int(np.sum(ranks != base_rank))})
        for scenario in SCENARIOS:
            sw = np.asarray(baseline["weights"][scenario], dtype=float).copy()
            sw[drop_idx] = 0.0
            sw = normalize_weights(sw)
            ss = np.asarray(baseline["ability_scores"]) @ sw
            sr = rankdata(-ss, method="average")
            ability_summary.append({"dropped_ability": ability, "ability_label": ABILITY_LABELS[ability], "scenario": scenario, "top_model": names[int(np.argmin(sr))], "kimi_rank": int(sr[kim_idx]), "kendall_tau_vs_baseline": float(kendalltau(np.asarray(baseline["ranks"][scenario]), sr).statistic), "rank_changed_count": int(np.sum(sr != np.asarray(baseline["ranks"][scenario])))})
            for i, name in enumerate(names):
                ability_detail.append({"dropped_ability": ability, "scenario": scenario, "model_name": name, "score": float(ss[i]), "rank": int(sr[i]), "baseline_rank": int(baseline["ranks"][scenario][i]), "rank_change": int(sr[i] - baseline["ranks"][scenario][i])})
    write_csv(RESULTS / "robustness_leave_one_ability_summary.csv", ability_summary)
    write_csv(RESULTS / "robustness_leave_one_ability_detail.csv", ability_detail)


def topsis_outputs(names: Sequence[str], baseline: Mapping[str, object]) -> None:
    """Weighted TOPSIS control using the unchanged seven-dimensional matrix."""
    matrix = np.asarray(baseline["ability_scores"], dtype=float)
    denom = np.sqrt(np.sum(matrix ** 2, axis=0))
    denom[denom <= 1e-12] = 1.0
    normalized = matrix / denom[None, :]
    weights = np.asarray(baseline["weights"]["问题一通用"], dtype=float)
    weighted = normalized * weights[None, :]
    ideal = np.max(weighted, axis=0)
    anti = np.min(weighted, axis=0)
    d_plus = np.sqrt(np.sum((weighted - ideal[None, :]) ** 2, axis=1))
    d_minus = np.sqrt(np.sum((weighted - anti[None, :]) ** 2, axis=1))
    closeness = d_minus / np.maximum(d_plus + d_minus, 1e-12)
    main_score = np.asarray(baseline["scores"]["问题一通用"], dtype=float)
    main_rank = rankdata(-main_score, method="average")
    topsis_rank = rankdata(-closeness, method="average")
    tau = float(kendalltau(main_rank, topsis_rank).statistic)
    main_top = {names[i] for i in np.argsort(main_rank)[:5]}
    topsis_top = {names[i] for i in np.argsort(topsis_rank)[:5]}
    rows = []
    for i, name in enumerate(names):
        rows.append({"model_name": name, "weighted_topsis_closeness": float(closeness[i]), "topsis_rank": int(topsis_rank[i]), "main_weighted_sum_score": float(main_score[i]), "main_rank": int(main_rank[i]), "rank_change_topsis_minus_main": int(topsis_rank[i] - main_rank[i]), "kimi_rank_in_main": int(main_rank[list(names).index("Kimi K3 (max)")]), "kimi_rank_in_topsis": int(topsis_rank[list(names).index("Kimi K3 (max)")])})
    write_csv(RESULTS / "robustness_topsis.csv", rows)
    write_json(RESULTS / "robustness_topsis_summary.json", {"kendall_tau_vs_main": tau, "top5_overlap": len(main_top & topsis_top) / 5.0, "kimi_rank_main": int(main_rank[list(names).index("Kimi K3 (max)")]), "kimi_rank_topsis": int(topsis_rank[list(names).index("Kimi K3 (max)")]), "weights": [float(x) for x in weights]})


def summarize_draws(names: Sequence[str], scores: np.ndarray, baseline_score: np.ndarray, scenario: str, scheme: str, draws: int) -> list[dict[str, object]]:
    ranks = np.vstack([rankdata(-row, method="average") for row in scores])
    top1 = np.argmax(scores, axis=1)
    baseline_rank = rankdata(-baseline_score, method="average")
    return [{"scheme": scheme, "scenario": scenario, "model_name": name, "draws": draws, "top1_probability": float(np.mean(top1 == i)), "top3_probability": float(np.mean(ranks[:, i] <= 3)), "mean_rank": float(np.mean(ranks[:, i])), "rank_std": float(np.std(ranks[:, i])), "baseline_rank": int(baseline_rank[i])} for i, name in enumerate(names)]


def dirichlet_weights(base: np.ndarray, draws: int, kappa: float, rng: np.random.Generator) -> np.ndarray:
    active = base > 0
    output = np.zeros((draws, len(base)), dtype=float)
    output[:, active] = rng.dirichlet(kappa * base[active], size=draws)
    return output


def workload_sensitivity_outputs(names: Sequence[str], analysis: Mapping[str, object], api_by_model: Mapping[str, Mapping[str, str]]) -> None:
    workloads = {
        "科研长文本": {"light": (20_000, 2_000), "medium": (80_000, 4_000), "heavy": (160_000, 8_000), "latency": 180.0},
        "大众日常对话": {"light": (1_000, 300), "medium": (2_000, 800), "heavy": (8_000, 2_000), "latency": 30.0},
        "计算机代码开发": {"light": (5_000, 1_000), "medium": (20_000, 4_000), "heavy": (50_000, 8_000), "latency": 90.0},
    }
    rows, stability = [], []
    front_sets = {}
    for scenario, spec in workloads.items():
        gate = np.asarray(analysis["eligibility"][scenario][0.25], dtype=bool)
        for tier in ("light", "medium", "heavy"):
            inp, out = spec[tier]
            panel = []
            for i, name in enumerate(names):
                api = api_by_model.get(name, {})
                pin, pout, e2e = to_float(api.get("input_price_usd_per_1m_tokens")), to_float(api.get("output_price_usd_per_1m_tokens")), to_float(api.get("e2e_seconds"))
                if pin is None or pout is None or e2e is None or pin <= 0 or pout <= 0:
                    continue
                panel.append({"scenario": scenario, "tier": tier, "model_name": name, "input_tokens_per_task": inp, "output_tokens_per_task": out, "quality_score": float(analysis["scores"][scenario][i]), "performance": float(analysis["scores"][scenario][i]), "raw_quality_score": float(analysis["scores"][scenario][i]), "raw_rank": int(analysis["ranks"][scenario][i]), "eligible_theta_025": bool(gate[i]), "cost_usd_per_1000_tasks": 1000.0 * (inp * pin + out * pout) / 1_000_000.0, "latency_seconds": e2e, "pareto_quality_cost": False, "pareto_quality_cost_latency": False, "frontier_type": "quality_cost_latency_3d"})
            eligible_panel = [row for row in panel if row["eligible_theta_025"]]
            for row in eligible_panel:
                dominated = any(float(other["quality_score"]) >= float(row["quality_score"]) - 1e-12 and float(other["cost_usd_per_1000_tasks"]) <= float(row["cost_usd_per_1000_tasks"]) + 1e-12 and (float(other["quality_score"]) > float(row["quality_score"]) + 1e-12 or float(other["cost_usd_per_1000_tasks"]) < float(row["cost_usd_per_1000_tasks"]) - 1e-12) for other in eligible_panel if other is not row)
                row["pareto_quality_cost"] = not dominated
            quality_latency_frontier = quality_cost_latency_pareto(eligible_panel)
            quality_latency_names = {row["model_name"] for row in quality_latency_frontier}
            for row in eligible_panel:
                row["pareto_quality_cost_latency"] = row["model_name"] in quality_latency_names
            # Workload stability must use the same three-objective frontier as
            # the primary problem-three model.  The two-objective quality-cost frontier
            # is retained in q3_workload_costs_long.csv only as a diagnostic.
            front_sets[(scenario, tier)] = {row["model_name"] for row in eligible_panel if row["pareto_quality_cost_latency"]}
            rows.extend(panel)
            # Budget recommendation uses the same hard gate as the primary
            # engineering Pareto path, then applies the E2E latency limit.
            eligible = [row for row in eligible_panel if float(row["latency_seconds"]) <= spec["latency"]]
            costs = sorted({round(float(row["cost_usd_per_1000_tasks"]), 8) for row in eligible})
            segments = []
            if costs and costs[0] > 0:
                segments.append({"scenario": scenario, "tier": tier, "budget_lower_usd_per_1000": 0.0, "budget_upper_usd_per_1000": costs[0], "recommended_model": "无可行模型", "quality_score": "", "latency_limit": spec["latency"]})
            previous = None
            switches = []
            for cost in costs:
                candidates = [row for row in eligible if float(row["cost_usd_per_1000_tasks"]) <= cost + 1e-9]
                winner = max(candidates, key=lambda row: (float(row["quality_score"]), -float(row["latency_seconds"])))
                if winner["model_name"] != previous:
                    switches.append((cost, winner))
                    previous = winner["model_name"]
            for idx, (start, winner) in enumerate(switches):
                end = switches[idx + 1][0] if idx + 1 < len(switches) else "inf"
                segments.append({"scenario": scenario, "tier": tier, "budget_lower_usd_per_1000": start, "budget_upper_usd_per_1000": end, "recommended_model": winner["model_name"], "quality_score": float(winner["quality_score"]), "latency_limit": spec["latency"]})
            write_csv(RESULTS / f"q3_budget_segments_{scenario}_{tier}.csv", segments)
    for scenario in SCENARIOS:
        med = front_sets[(scenario, "medium")]
        for tier in ("light", "heavy"):
            other = front_sets[(scenario, tier)]
            union = med | other
            stability.append({"scenario": scenario, "comparison": f"medium_vs_{tier}", "frontier_type": "quality_cost_latency_3d", "medium_frontier_size": len(med), "other_frontier_size": len(other), "intersection_size": len(med & other), "union_size": len(union), "jaccard_frontier": len(med & other) / len(union) if union else 1.0})
    write_csv(RESULTS / "q3_workload_costs_long.csv", rows)
    write_csv(RESULTS / "q3_workload_pareto_stability.csv", stability)


def _rank_compare(names: Sequence[str], base_rank: np.ndarray, other_rank: np.ndarray) -> dict[str, object]:
    """Return rank agreement measures on one fixed model panel."""
    base_order = np.argsort(base_rank)
    other_order = np.argsort(other_rank)
    top5_base = {names[i] for i in base_order[:5]}
    top5_other = {names[i] for i in other_order[:5]}
    return {
        "kendall_tau": float(kendalltau(base_rank, other_rank).statistic),
        "spearman_rho": float(spearmanr(base_rank, other_rank).statistic),
        "top5_overlap": float(len(top5_base & top5_other) / 5.0),
        "top_model": names[int(other_order[0])],
        "kimi_rank": int(other_rank[list(names).index("Kimi K3 (max)")]),
    }


def standardization_sensitivity_outputs(names: Sequence[str], raw: np.ndarray, baseline: Mapping[str, object]) -> None:
    """Compare three defensible scales while leaving the quantile main model frozen."""
    variants = {
        "分位数（主模型）": baseline,
        "Min-Max": analyze_scores(raw, names, normalization="minmax"),
        "Robust-Z（中位数/IQR）": analyze_scores(raw, names, normalization="robust-z"),
    }
    base_rank = np.asarray(baseline["ranks"]["问题一通用"], dtype=float)
    rows = []
    for label, result in variants.items():
        rank = np.asarray(result["ranks"]["问题一通用"], dtype=float)
        comp = _rank_compare(names, base_rank, rank)
        rows.append({
            "reference": "分位数（主模型）", "variant": label,
            "normalization_formula": {"分位数（主模型）": "(rank-1)/(n-1)", "Min-Max": "(x-min)/(max-min)", "Robust-Z（中位数/IQR）": "(x-median)/IQR"}[label],
            **comp,
            "rank_is_main": bool(np.array_equal(rank, base_rank)),
        })
    write_csv(RESULTS / "robustness_standardization_equal_weight.csv", rows)


def coverage_threshold_outputs(names: Sequence[str], raw: np.ndarray, baseline: Mapping[str, object]) -> None:
    """Audit 60/70/80/90% admission without imputing extension scores."""
    coverage_rows = read_csv(DATA_DIR / "coverage_matrix.csv")
    thresholds = (0.60, 0.70, 0.80, 0.90)
    detail = []
    summary = []
    indicator_ids = {item["id"] for item in INDICATORS}
    core_source_to_id = {item["source"]: item["id"] for item in INDICATORS}
    for threshold in thresholds:
        admitted = [row["benchmark"] for row in coverage_rows if float(row["coverage_rate_27"]) >= threshold]
        admitted_core = [core_source_to_id[row["benchmark"]] for row in coverage_rows if row["benchmark"] in core_source_to_id and float(row["coverage_rate_27"]) >= threshold]
        usable = [item["id"] for item in INDICATORS if item["id"] in admitted_core]
        # Only complete core indicators can be scored.  Extension indicators
        # are reported as candidates and never filled or inserted here.
        keep = [j for j, item in enumerate(INDICATORS) if item["id"] in usable]
        if not keep:
            rank = np.full(len(names), np.nan)
            score = np.full(len(names), np.nan)
        else:
            z = np.column_stack([rank_percentile(raw[:, j]) for j in keep])
            ability_blocks = []
            present = []
            for ability in ABILITIES:
                idx = [pos for pos, j in enumerate(keep) if INDICATORS[j]["ability"] == ability]
                present.append(bool(idx))
                ability_blocks.append(np.mean(z[:, idx], axis=1) if idx else np.zeros(len(names)))
            ability_matrix = np.column_stack(ability_blocks)
            weights = normalize_weights(np.where(np.asarray(present, dtype=bool), 1.0, 0.0))
            score = ability_matrix @ weights
            rank = rankdata(-score, method="average")
        comp = _rank_compare(names, np.asarray(baseline["ranks"]["问题一通用"], dtype=float), rank) if np.all(np.isfinite(rank)) else {"kendall_tau": np.nan, "spearman_rho": np.nan, "top5_overlap": 0.0, "top_model": "无可比结果", "kimi_rank": ""}
        summary.append({
            "threshold": threshold, "threshold_percent": f"{threshold:.0%}",
            "admitted_candidate_count": len(admitted), "admitted_candidate_set": ";".join(admitted),
            "admitted_core_count": len(admitted_core), "admitted_core_set": ";".join(admitted_core),
            "usable_complete_core_count": len(usable), "usable_complete_core_set": ";".join(usable),
            "core_set_same_as_main": set(usable) == indicator_ids,
            "no_extension_imputation": True, **comp,
        })
        for row in coverage_rows:
            detail.append({
                "threshold": threshold, "threshold_percent": f"{threshold:.0%}", "benchmark": row["benchmark"],
                "panel_role": row["panel_role"], "coverage_rate_27": row["coverage_rate_27"],
                "admitted_candidate": float(row["coverage_rate_27"]) >= threshold,
                "enters_main_complete_matrix": row["benchmark"] in core_source_to_id and float(row["coverage_rate_27"]) >= threshold,
                "imputation_used": False,
            })
    write_csv(RESULTS / "coverage_threshold_sensitivity.csv", summary)
    write_csv(RESULTS / "coverage_threshold_admission.csv", detail)


def model_family_outputs(names: Sequence[str], baseline: Mapping[str, object], api_by_model: Mapping[str, Mapping[str, str]]) -> None:
    """Compare vendor representatives only; never correlate unequal panels."""
    groups: dict[str, list[str]] = defaultdict(list)
    generic = np.asarray(baseline["scores"]["问题一通用"], dtype=float)
    for i, name in enumerate(names):
        creator = str(api_by_model.get(name, {}).get("model_creator", "")).strip() or "未知厂商"
        groups[creator].append(name)
    records = []
    for creator, members in sorted(groups.items()):
        best = max(members, key=lambda n: (generic[list(names).index(n)], n))
        latest = max(members, key=lambda n: (str(api_by_model.get(n, {}).get("release_date", "")), generic[list(names).index(n)], n))
        for scheme, selected in (("每厂商最高通用分配置", best), ("每厂商最新发布配置", latest)):
            records.append({"creator": creator, "scheme": scheme, "representative_model": selected, "member_count": len(members), "generic_score": float(generic[list(names).index(selected)]), "release_date": api_by_model.get(selected, {}).get("release_date", "")})
    detail = []
    by_scheme = {}
    for scheme in ("每厂商最高通用分配置", "每厂商最新发布配置"):
        rows = [r for r in records if r["scheme"] == scheme]
        rows.sort(key=lambda r: (-float(r["generic_score"]), r["creator"]))
        for rank, row in enumerate(rows, 1):
            detail.append({**row, "representative_rank": rank, "comparison_scope": "厂商代表层"})
        by_scheme[scheme] = {r["creator"]: (r["representative_model"], float(r["generic_score"])) for r in rows}
    creators = sorted(set(by_scheme["每厂商最高通用分配置"]) & set(by_scheme["每厂商最新发布配置"]))
    best_scores = np.asarray([by_scheme["每厂商最高通用分配置"][c][1] for c in creators])
    latest_scores = np.asarray([by_scheme["每厂商最新发布配置"][c][1] for c in creators])
    best_ranks, latest_ranks = rankdata(-best_scores, method="average"), rankdata(-latest_scores, method="average")
    summary = [{
        "comparison": "最高通用分 vs 最新发布", "comparison_scope": "仅在相同厂商代表层比较，不与27配置全样本直接做Kendall",
        "vendor_count": len(creators), "kendall_tau": float(kendalltau(best_ranks, latest_ranks).statistic),
        "spearman_rho": float(spearmanr(best_ranks, latest_ranks).statistic), "top5_overlap": len(set(np.argsort(best_ranks)[:5]) & set(np.argsort(latest_ranks)[:5])) / min(5, len(creators)),
        "representative_panel_sizes": "相同厂商集合/相同样本数",
    }]
    write_csv(RESULTS / "robustness_model_family.csv", detail)
    write_csv(RESULTS / "robustness_model_family_summary.csv", summary)


def latency_threshold_outputs(scenario_rows: Mapping[str, Sequence[Mapping[str, object]]], analysis: Mapping[str, object]) -> None:
    summary, segments = [], []
    for scenario in SCENARIOS:
        gate_rows = [row for row in scenario_rows[scenario] if row.get("eligible_theta_025") in {True, "True"}]
        for threshold in LATENCY_THRESHOLDS[scenario]:
            feasible = [row for row in gate_rows if float(row["latency_seconds"]) <= threshold]
            segs = budget_segments(gate_rows, "quality_score", "cost_usd_per_1000_tasks", "latency_seconds", threshold)
            recs = [row["recommended_model"] for row in segs if row.get("recommended_model") not in {"", "无可行模型"}]
            summary.append({"scenario": scenario, "latency_threshold_seconds": threshold, "eligible_gate_count": len(gate_rows), "feasible_count": len(feasible), "recommended_sequence": " -> ".join(recs) if recs else "无可行模型", "all_recommendations_eligible": all(r in {x["model_name"] for x in gate_rows} for r in recs)})
            for row in segs:
                segments.append({"scenario": scenario, "latency_threshold_seconds": threshold, **row})
    write_csv(RESULTS / "q3_latency_threshold_summary.csv", summary)
    write_csv(RESULTS / "q3_latency_threshold_segments.csv", segments)


def cache_sensitivity_outputs(scenario_rows: Mapping[str, Sequence[Mapping[str, object]]], analysis: Mapping[str, object], api_by_model: Mapping[str, Mapping[str, str]]) -> None:
    """Reprice the 19 configurations with a positive cache-hit price."""
    costs, pareto_rows, segment_rows, summary = [], [], [], []
    for scenario in SCENARIOS:
        base_rows = [row for row in scenario_rows[scenario] if to_float(api_by_model.get(row["model_name"], {}).get("cache_hit_price_usd_per_1m_tokens")) is not None and to_float(api_by_model.get(row["model_name"], {}).get("cache_hit_price_usd_per_1m_tokens")) > 0]
        for h in CACHE_HIT_RATES:
            priced = []
            for row in base_rows:
                api = api_by_model[row["model_name"]]
                pin, pout = float(api["input_price_usd_per_1m_tokens"]), float(api["output_price_usd_per_1m_tokens"])
                pcache = float(api["cache_hit_price_usd_per_1m_tokens"])
                cost = 1000.0 * (float(row["input_tokens_per_task"]) * ((1.0 - h) * pin + h * pcache) + float(row["output_tokens_per_task"]) * pout) / 1_000_000.0
                new = dict(row); new.update({"h_cache": h, "cache_input_price_usd_per_1m_tokens": pcache, "cost_usd_per_1000_tasks": cost, "cache_panel_size": len(base_rows), "cache_formula": "input*((1-h)*pin+h*pcache)+output*pout"})
                priced.append(new); costs.append(new)
            eligible = [r for r in priced if r.get("eligible_theta_025") in {True, "True"}]
            front = quality_cost_latency_pareto(eligible)
            for row in front:
                pareto_rows.append({**row, "h_cache": h, "cache_panel_size": len(base_rows)})
            segs = budget_segments(eligible, "quality_score", "cost_usd_per_1000_tasks", "latency_seconds", WORKLOADS[scenario]["latency_limit"])
            recs = [r["recommended_model"] for r in segs if r.get("recommended_model") not in {"", "无可行模型"}]
            for row in segs:
                segment_rows.append({"scenario": scenario, "h_cache": h, "cache_panel_size": len(base_rows), **row})
            summary.append({"scenario": scenario, "h_cache": h, "cache_panel_size": len(base_rows), "eligible_count": len(eligible), "pareto_count": len(front), "recommended_sequence": " -> ".join(recs) if recs else "无可行模型", "formula": "input*((1-h)*pin+h*pcache)+output*pout"})
    write_csv(RESULTS / "q3_cache_sensitivity_costs_long.csv", costs)
    write_csv(RESULTS / "q3_cache_sensitivity_pareto.csv", pareto_rows)
    write_csv(RESULTS / "q3_cache_sensitivity_budget_segments.csv", segment_rows)
    write_csv(RESULTS / "q3_cache_sensitivity_summary.csv", summary)


def pareto_monte_carlo_outputs(names: Sequence[str], analysis: Mapping[str, object], api_by_model: Mapping[str, Mapping[str, str]]) -> None:
    """Estimate Pareto membership on the already reported L/M/H and latency grids."""
    rng = np.random.default_rng(V3_SEED)
    abilities = np.asarray(analysis["ability_scores"], dtype=float)
    hits = {scenario: {name: 0 for name in names} for scenario in SCENARIOS}
    feasible_draws = {scenario: 0 for scenario in SCENARIOS}
    frontier_size_sums = {scenario: 0 for scenario in SCENARIOS}
    frontier_size_max = {scenario: 0 for scenario in SCENARIOS}
    q3_names = [name for name in names if name in api_by_model and to_float(api_by_model[name].get("input_price_usd_per_1m_tokens")) is not None and to_float(api_by_model[name].get("output_price_usd_per_1m_tokens")) is not None and float(api_by_model[name].get("input_price_usd_per_1m_tokens")) > 0 and float(api_by_model[name].get("output_price_usd_per_1m_tokens")) > 0 and to_float(api_by_model[name].get("e2e_seconds")) is not None and name != "Command A+"]
    for scenario in SCENARIOS:
        gate = np.asarray(analysis["eligibility"][scenario][0.25], dtype=bool)
        for _ in range(V3_MONTE_CARLO_DRAWS):
            tier = str(rng.choice(("light", "medium", "heavy")))
            threshold = float(rng.choice(LATENCY_THRESHOLDS[scenario]))
            base = np.asarray(analysis["weights"][scenario], dtype=float)
            weights = rng.dirichlet(V3_MONTE_CARLO_KAPPA * base)
            inp, out = WORKLOAD_SENSITIVITY[scenario][tier]
            panel = []
            for name in q3_names:
                i = list(names).index(name)
                if not gate[i]:
                    continue
                api = api_by_model[name]
                e2e = float(api["e2e_seconds"])
                if e2e > threshold:
                    continue
                cost = 1000.0 * (inp * float(api["input_price_usd_per_1m_tokens"]) + out * float(api["output_price_usd_per_1m_tokens"])) / 1_000_000.0
                panel.append({"model_name": name, "quality_score": float(abilities[i] @ weights), "cost_usd_per_1000_tasks": cost, "latency_seconds": e2e})
            if panel:
                feasible_draws[scenario] += 1
            frontier = quality_cost_latency_pareto(panel)
            frontier_size_sums[scenario] += len(frontier)
            frontier_size_max[scenario] = max(frontier_size_max[scenario], len(frontier))
            for row in frontier:
                hits[scenario][row["model_name"]] += 1
    rows = []
    summary_rows = []
    for scenario in SCENARIOS:
        mean_frontier_size = frontier_size_sums[scenario] / V3_MONTE_CARLO_DRAWS
        max_frequency = max(hits[scenario].values()) / V3_MONTE_CARLO_DRAWS
        max_models = sorted(name for name, count in hits[scenario].items() if count == max(hits[scenario].values()))
        summary_rows.append({
            "scenario": scenario,
            "draws": V3_MONTE_CARLO_DRAWS,
            "mean_frontier_size": mean_frontier_size,
            "max_frontier_size": frontier_size_max[scenario],
            "max_frequency": max_frequency,
            "max_frequency_models": ";".join(max_models),
            "total_frontier_memberships": frontier_size_sums[scenario],
            "feasible_draws": feasible_draws[scenario],
            "seed": V3_SEED,
            "dirichlet_kappa": V3_MONTE_CARLO_KAPPA,
            "denominator_rule": "全部5000次；不满足theta或超过抽中时延阈值不进前沿",
        })
        for name in names:
            rows.append({"scenario": scenario, "model_name": name, "draws": V3_MONTE_CARLO_DRAWS, "pareto_hits": hits[scenario][name], "pareto_stable_frequency": hits[scenario][name] / V3_MONTE_CARLO_DRAWS, "feasible_draws": feasible_draws[scenario], "mean_frontier_size": mean_frontier_size, "max_frontier_size": frontier_size_max[scenario], "seed": V3_SEED, "dirichlet_kappa": V3_MONTE_CARLO_KAPPA, "workload_tiers": "light;medium;heavy (等概率)", "latency_thresholds_seconds": ";".join(str(x) for x in LATENCY_THRESHOLDS[scenario]), "theta": 0.25, "denominator_rule": "全部5000次；不满足theta或超过抽中时延阈值不进前沿"})
    write_csv(RESULTS / "robustness_pareto_monte_carlo.csv", rows)
    write_csv(RESULTS / "q3_pareto_monte_carlo_summary.csv", summary_rows)
    write_json(RESULTS / "robustness_pareto_monte_carlo_config.json", {"draws": V3_MONTE_CARLO_DRAWS, "seed": V3_SEED, "dirichlet_kappa": V3_MONTE_CARLO_KAPPA, "workload_tiers": {k: {tier: list(v) for tier, v in value.items()} for k, value in WORKLOAD_SENSITIVITY.items()}, "latency_thresholds_seconds": LATENCY_THRESHOLDS, "theta": 0.25, "denominator": V3_MONTE_CARLO_DRAWS, "note": "每次随机抽取既有L/M/H负载和本场景四个时延阈值；不满足资格或时延的配置当次不在前沿"})


def leave_one_model_fit_outputs(scenario_rows: Mapping[str, Sequence[Mapping[str, object]]]) -> None:
    """LOMO influence audit for the existing candidate cost curves."""
    detail, summary = [], []
    for scenario, all_rows in scenario_rows.items():
        rows = [row for row in all_rows if row.get("eligible_theta_025") in {True, "True"}]
        x = np.asarray([float(row["cost_usd_per_1000_tasks"]) for row in rows]); y = np.asarray([float(row["performance"]) for row in rows])
        base_fits = fit_models(x, y)
        baseline_best = min(base_fits, key=lambda name: (float(base_fits[name]["loocv_rmse"]), float(base_fits[name]["aicc"])))
        selected = []
        for drop_i, dropped in enumerate(rows):
            keep = np.ones(len(rows), dtype=bool); keep[drop_i] = False
            fits = fit_models(x[keep], y[keep])
            best = min(fits, key=lambda name: (float(fits[name]["loocv_rmse"]), float(fits[name]["aicc"])))
            selected.append(best)
            for model, result in fits.items():
                detail.append({"scenario": scenario, "deleted_model": dropped["model_name"], "candidate_function": model, "selected_after_deletion": model == best, "baseline_selected_function": baseline_best, "loocv_rmse": result["loocv_rmse"], "aicc": result["aicc"], "params": json.dumps(result.get("params", {}), ensure_ascii=False), "n_samples": int(np.sum(keep))})
        selected_results = [next((r for r in detail[::-1] if r["scenario"] == scenario and r["deleted_model"] == dropped["model_name"] and r["candidate_function"] == selected[idx]), None) for idx, dropped in enumerate(rows)]
        selected_rmse = [float(r["loocv_rmse"]) for r in selected_results if r is not None and math.isfinite(float(r["loocv_rmse"]))]
        param_ranges: dict[str, list[float]] = defaultdict(list)
        for r in selected_results:
            if r is None: continue
            for key, value in json.loads(r["params"]).items():
                if isinstance(value, (int, float)) and math.isfinite(float(value)): param_ranges[key].append(float(value))
        summary.append({"scenario": scenario, "baseline_selected_function": baseline_best, "deletion_count": len(rows), "same_function_count": sum(x == baseline_best for x in selected), "same_function_rate": sum(x == baseline_best for x in selected) / len(selected), "changed_deletions": ";".join(rows[i]["model_name"] for i, x in enumerate(selected) if x != baseline_best), "selected_loocv_rmse_min": min(selected_rmse) if selected_rmse else "", "selected_loocv_rmse_max": max(selected_rmse) if selected_rmse else "", "selected_parameter_ranges": json.dumps({k: [min(v), max(v)] for k, v in param_ranges.items()}, ensure_ascii=False), "interpretation": "删除单个可推荐配置后的函数选择影响审计，不作因果推断"})
    write_csv(RESULTS / "q3_fit_leave_one_model_out.csv", detail)
    write_csv(RESULTS / "q3_fit_leave_one_model_out_summary.csv", summary)


def robustness_outputs(names: Sequence[str], raw: np.ndarray, baseline: Mapping[str, object], api_by_model: Mapping[str, Mapping[str, str]], scenario_rows: Mapping[str, Sequence[Mapping[str, object]]]) -> None:
    # Structural controls and parameter grids are all generated from the
    # same frozen 27/20 panels; none feed back into the main ranking.
    standardization_sensitivity_outputs(names, raw, baseline)
    topsis_outputs(names, baseline)
    leave_one_outputs(names, raw, baseline)
    coverage_threshold_outputs(names, raw, baseline)
    model_family_outputs(names, baseline, api_by_model)
    rng = np.random.default_rng(SEED + 101)
    draws = 10_000
    kappa = 100.0
    generic = np.asarray(baseline["weights"]["问题一通用"], dtype=float)
    all_rows = []
    generic_draws = dirichlet_weights(generic, draws, kappa, rng)
    all_rows.extend(summarize_draws(names, generic_draws @ np.asarray(baseline["ability_scores"]).T, baseline["scores"]["问题一通用"], "通用", "Dirichlet-通用权重", draws))
    for scenario in SCENARIOS:
        demand = np.asarray([SCENARIO_DEMAND[scenario][a] for a in ABILITIES])
        derived = generic_draws * demand[None, :]
        derived /= np.sum(derived, axis=1, keepdims=True)
        all_rows.extend(summarize_draws(names, derived @ np.asarray(baseline["ability_scores"]).T, baseline["scores"][scenario], scenario, "Dirichlet-通用到场景", draws))
        sw = np.asarray(baseline["weights"][scenario], dtype=float)
        direct = dirichlet_weights(sw, draws, kappa, rng)
        all_rows.extend(summarize_draws(names, direct @ np.asarray(baseline["ability_scores"]).T, baseline["scores"][scenario], scenario, "Dirichlet-场景直接", draws))
    write_csv(RESULTS / "robustness_dirichlet_rank.csv", all_rows)
    demand_rows = []
    for scenario in SCENARIOS:
        base = np.asarray([SCENARIO_DEMAND[scenario][a] for a in ABILITIES])
        factors = rng.uniform(0.8, 1.2, size=(draws, len(ABILITIES)))
        factors[:, base == 0] = 0.0
        wdraw = factors * base[None, :]
        wdraw /= np.sum(wdraw, axis=1, keepdims=True)
        demand_rows.extend(summarize_draws(names, wdraw @ np.asarray(baseline["ability_scores"]).T, baseline["scores"][scenario], scenario, "任务需求±20%", draws))
    write_csv(RESULTS / "robustness_demand_pm20.csv", demand_rows)
    status_rows = []
    for scenario in SCENARIOS:
        for theta, mask in baseline["eligibility"][scenario].items():
            for i, name in enumerate(names):
                status_rows.append({"scenario": scenario, "theta": theta, "model_name": name, "critical_abilities": ";".join(CRITICAL_ABILITIES[scenario]), "eligible": bool(mask[i]), "raw_quality_score": float(baseline["scores"][scenario][i]), "raw_rank": int(baseline["ranks"][scenario][i])})
    write_csv(RESULTS / "eligibility_status.csv", status_rows)
    workload_sensitivity_outputs(names, baseline, api_by_model)
    # Keep the legacy audit table, but extend it to the four V3 thresholds so
    # existing workbook consumers remain readable.
    coverage_rows = read_csv(DATA_DIR / "coverage_matrix.csv")
    admission = []
    for row in coverage_rows:
        for panel, col, size in [("27配置", "coverage_rate_27", 27), ("21配置交集", "coverage_rate_21_main", 21)]:
            rate = float(row[col])
            for threshold in (0.60, 0.70, 0.80, 0.90):
                admission.append({"benchmark": row["benchmark"], "panel": panel, "panel_size": size, "panel_role": row["panel_role"], "coverage_rate": rate, "threshold": threshold, "admitted_candidate": rate >= threshold, "note": "通过阈值仍需明确缺失处理；不自动进入27配置主排名" if rate >= threshold else "覆盖率不足"})
    write_csv(RESULTS / "coverage_admission.csv", admission)
    latency_threshold_outputs(scenario_rows, baseline)
    cache_sensitivity_outputs(scenario_rows, baseline, api_by_model)
    pareto_monte_carlo_outputs(names, baseline, api_by_model)
    leave_one_model_fit_outputs(scenario_rows)


def savefig_pair(fig: plt.Figure, stem: str) -> None:
    FIGURES.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIGURES / f"{stem}.svg", bbox_inches="tight")
    fig.savefig(FIGURES / f"{stem}.pdf", bbox_inches="tight")
    fig.savefig(FIGURES / f"{stem}.png", bbox_inches="tight", dpi=220)
    plt.close(fig)


def short_name(name: str, max_len: int = 18) -> str:
    return name if len(name) <= max_len else name[: max_len - 1] + "…"


def diagnostic_label(item: Mapping[str, object]) -> str:
    """Return the label used by correlation diagnostics."""
    return str(item["label"])


def high_corr_review(item_a: Mapping[str, object], item_b: Mapping[str, object]) -> dict[str, str]:
    """Return the semantic review for one rho>=.85 indicator pair.

    A same-dimension fallback is retained so the output remains auditable if
    the frozen panel gains another indicator in an existing dimension.  Any
    cross-dimension pair not explicitly reviewed is conservatively kept and
    marked for semantic review rather than being deleted mechanically.
    """
    key = tuple(sorted((str(item_a["id"]), str(item_b["id"]))))
    review = HIGH_CORR_REVIEW.get(key)
    if review is not None:
        return dict(review)
    same_dimension = item_a["ability"] == item_b["ability"]
    if same_dimension:
        return {
            "constructs_highly_overlapping": "是",
            "substantive_redundancy": "待审查",
            "final_treatment": f"保留于 {item_a['ability']} 内，待构念审查后融合",
            "treatment_reason": "同一核心评价维度内的高相关候选；需结合测量构念、覆盖率、区分度和来源可靠性决定是否融合。",
        }
    return {
        "constructs_highly_overlapping": "否",
        "substantive_redundancy": "否",
        "final_treatment": f"分别保留（{item_a['ability']}、{item_b['ability']}）",
        "treatment_reason": "跨维度高相关只提出潜在冗余候选；当前未发现足以替代另一维度的同构构念，保留并在后续结合覆盖率、区分度和来源可靠性复核。",
    }


def figure_outputs(names: Sequence[str], raw: np.ndarray, analysis: Mapping[str, object], rho: np.ndarray, linkage_matrix: np.ndarray, scenario_rows: Mapping[str, Sequence[Mapping[str, object]]]) -> None:
    configure_plot_style()
    # 1. Method flow.
    fig, ax = plt.subplots(figsize=(10, 2.6))
    ax.axis("off")
    labels = [
        "公开 Benchmark",
        "方向统一与\n分位数标准化",
        "七项核心评价维度\n与通用无偏好权重",
        "任务链需求\n与场景得分",
        "价格、时延\n与工程决策",
    ]
    centers = np.linspace(0.10, 0.90, len(labels))
    center_y, box_width, box_height = 0.50, 0.155, 0.285
    bottom = center_y - box_height / 2
    for center_x, text in zip(centers, labels):
        box = FancyBboxPatch(
            (center_x - box_width / 2, bottom),
            box_width,
            box_height,
            boxstyle="round,pad=0.012,rounding_size=0.035",
            transform=ax.transAxes,
            facecolor="#eef3f8",
            edgecolor="#47759d",
            linewidth=1.35,
            zorder=2,
        )
        ax.add_patch(box)
        ax.text(center_x, center_y, text, ha="center", va="center", transform=ax.transAxes, fontsize=10.5, linespacing=1.05, zorder=3)
    for left, right in zip(centers[:-1], centers[1:]):
        ax.annotate(
            "",
            xy=(right - box_width / 2, center_y),
            xytext=(left + box_width / 2, center_y),
            xycoords=ax.transAxes,
            arrowprops=dict(
                arrowstyle="-|>",
                mutation_scale=11,
                linewidth=1.25,
                color="#5a6168",
                shrinkA=0,
                shrinkB=0,
                connectionstyle="arc3,rad=0",
            ),
            zorder=4,
        )
    fig.subplots_adjust(left=0.02, right=0.98, top=0.92, bottom=0.08)
    savefig_pair(fig, "fig01_method_flow")
    # 2. Coverage: candidate panel and core/extension eligibility.
    fig, ax = plt.subplots(figsize=(8.5, 4.2))
    candidate_rows = read_csv(DATA_DIR / "scores_long.csv")
    candidate_models = {row.get("model_name_display", "") for row in candidate_rows if row.get("model_name_display", "")}
    candidate_benchmarks = [
        ("HLE", "核心"), ("GPQA Diamond", "核心"), ("Omniscience Accuracy", "核心"), ("Non-Hallucination", "核心"), ("AA-LCR", "核心"), ("SciCode", "核心"), ("Terminal-Bench", "核心"), ("tau3-Banking", "核心"),
        ("IFBench", "扩展"), ("LiveCodeBench", "扩展"), ("MMMU-Pro", "扩展"), ("Global-MMLU-Lite", "扩展"),
    ]
    source_by_label = {item["label"]: item["source"] for item in INDICATORS}
    source_by_label.update({"tau3-Banking": "tau3-Banking"})
    coverage, labels, colors = [], [], []
    for label, group in candidate_benchmarks:
        source = source_by_label.get(label, label)
        observed = {row.get("model_name_display", "") for row in candidate_rows if row.get("benchmark_display_name") == source and to_float(row.get("score")) is not None}
        coverage.append(len(observed & candidate_models) / max(len(candidate_models), 1))
        labels.append(label)
        colors.append("#47759d" if group == "核心" else "#61a96b")
    ax.barh(labels[::-1], coverage[::-1], color=colors[::-1])
    ax.set_xlim(0, 1.08)
    ax.set_xlabel("27个候选配置中的可用比例")
    ax.xaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1.0))
    ax.axvline(0.70, color="#b44", linestyle="--", linewidth=1, label="70%纳入阈值")
    for yi, val in enumerate(coverage[::-1]):
        ax.text(val + 0.015, yi, f"{val:.0%}", va="center", fontsize=8)
    from matplotlib.patches import Patch
    ax.legend(handles=[Patch(color="#47759d", label="核心指标"), Patch(color="#61a96b", label="扩展指标"), matplotlib.lines.Line2D([0], [0], color="#b44", linestyle="--", label="70%阈值")], frameon=False, fontsize=8, loc="lower right")
    savefig_pair(fig, "fig02_coverage")
    # 3. Spearman heatmap.
    fig, ax = plt.subplots(figsize=(7.4, 6.5))
    im = ax.imshow(rho, vmin=-1, vmax=1, cmap="RdBu_r")
    labels = [diagnostic_label(item) for item in INDICATORS]
    ax.set_xticks(range(len(labels)), labels, rotation=55, ha="right")
    ax.set_yticks(range(len(labels)), labels)
    for i in range(len(labels)):
        for j in range(len(labels)):
            ax.text(j, i, f"{rho[i,j]:.2f}", ha="center", va="center", fontsize=6.5, color="black" if abs(rho[i,j]) < 0.7 else "white")
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04, label="Spearman ρ")
    savefig_pair(fig, "fig03_spearman_heatmap")
    # 4. Average-linkage dendrogram (diagnostic only; never an automatic
    # deletion rule).
    fig, ax = plt.subplots(figsize=(9, 4.8))
    dendrogram(linkage_matrix, labels=[diagnostic_label(item) for item in INDICATORS], leaf_rotation=45, leaf_font_size=8, ax=ax, color_threshold=0.15)
    ax.axhline(1 - 0.85, color="#b44", linestyle="--", linewidth=0.9, label="ρ=0.85预警线")
    ax.set_ylabel("距离 1−ρ（效益方向）")
    ax.legend(frameon=False, fontsize=8)
    savefig_pair(fig, "fig04_indicator_dendrogram")
    # 5. Overall ranking.
    order = np.argsort(-np.asarray(analysis["scores"]["问题一通用"]))[:12]
    fig, ax = plt.subplots(figsize=(10.0, 5.5))
    vals = np.asarray(analysis["scores"]["问题一通用"])[order]
    bars = ax.barh([names[i] for i in order[::-1]], vals[::-1], color=["#d95f02" if names[i] == "Kimi K3 (max)" else "#47759d" for i in order[::-1]])
    ax.set_title("27个配置中的通用综合得分前12名")
    ax.set_xlabel("通用综合得分（相对分位评价）")
    ax.grid(axis="x")
    ax.tick_params(axis="y", labelsize=8.5)
    fig.subplots_adjust(left=0.34, right=0.97, top=0.96, bottom=0.12)
    for bar, val in zip(bars, vals[::-1]):
        ax.text(float(val) + 0.006, bar.get_y() + bar.get_height() / 2, f"{val:.3f}", va="center", fontsize=7)
    savefig_pair(fig, "fig05_overall_ranking")
    # 6. Kimi profile.
    ki = list(names).index("Kimi K3 (max)")
    fig, ax = plt.subplots(figsize=(8.5, 4.7))
    kimi = np.asarray(analysis["ability_scores"])[ki]
    mean = np.mean(np.asarray(analysis["ability_scores"]), axis=0)
    x = np.arange(len(ABILITIES))
    width = 0.38
    ax.bar(x - width / 2, kimi, width, label="Kimi K3 (max)", color="#d95f02")
    ax.bar(x + width / 2, mean, width, label="27个质量配置均值", color="#9ecae1")
    compact_ability_labels = ["C1\n推理", "C2\n知识正确性", "C3\n知识边界\n校准", "C4\n长文本", "C5\n代码与\n科学计算", "C6\n软件工程\n与工具执行", "C7\n指令交互\n与任务完成"]
    ax.set_xticks(x, compact_ability_labels)
    ax.set_ylim(0, 1)
    ax.set_ylabel("相对分位得分")
    ax.legend(frameon=False, loc="upper left")
    savefig_pair(fig, "fig06_kimi_profile")
    # 7. Scenario ranking slope.
    fig, ax = plt.subplots(figsize=(8.7, 5.1))
    scenarios = ["科研长文本", "大众日常对话", "计算机代码开发"]
    # Keep the cross-scenario trajectories of models appearing in at least
    # one scenario's top five.  The underlying 27-model rankings remain
    # unchanged; this only removes low-ranking trajectories from the figure.
    scenario_top5 = {
        scenario: set(np.argsort(-np.asarray(analysis["scores"][scenario], dtype=float))[:5])
        for scenario in scenarios
    }
    plotted_indices = sorted(set().union(*scenario_top5.values()))
    for i in plotted_indices:
        name = names[i]
        ranks = [analysis["ranks"][s][i] for s in scenarios]
        color = "#d95f02" if name == "Kimi K3 (max)" else "#bdbdbd"
        ax.plot(range(3), ranks, marker="o", lw=2.0 if name == "Kimi K3 (max)" else 0.7, alpha=1 if name == "Kimi K3 (max)" else 0.55, color=color)
        if name == "Kimi K3 (max)":
            for xx, rr in enumerate(ranks):
                if xx in (0, 2):
                    ax.text(xx + 0.03, rr, name, fontsize=8, va="center")
    ax.set_xticks(range(3), scenarios)
    ax.set_ylim(27.5, 0.5)
    ax.set_ylabel("名次（越靠上越好）")
    ax.grid(axis="y")
    fig.suptitle("27个配置中的三类场景前五名", fontsize=11, y=1.01)
    fig.subplots_adjust(top=0.88)
    savefig_pair(fig, "fig07_scenario_ranking")
    # 8. Kimi exact decomposition.
    fig, ax = plt.subplots(figsize=(8.7, 4.6))
    drows = read_csv(RESULTS / "scenario_decomposition.csv")
    chosen = next(r for r in drows if r["model_name"] == "Kimi K3 (max)" and r["from_scenario"] == "科研长文本" and r["to_scenario"] == "大众日常对话")
    vals = [to_float(chosen[f"delta_{a}"]) or 0 for a in ABILITIES]
    colors = ["#2ca25f" if v >= 0 else "#d95f02" for v in vals]
    ax.bar(ABILITIES, vals, color=colors)
    ax.axhline(0, color="#444", linewidth=0.8)
    ax.set_ylabel("对综合得分变化的贡献")
    ax.set_ylim(min(vals) - 0.055, max(vals) + 0.045)
    for i, val in enumerate(vals):
        ax.text(i, val + (0.006 if val >= 0 else -0.012), f"{val:+.3f}", ha="center", va="bottom" if val >= 0 else "top", fontsize=8)
    savefig_pair(fig, "fig08_kimi_decomposition")
    # 9. Three-objective Pareto frontier projected onto the quality-fee plane.
    fig, axes = plt.subplots(1, 3, figsize=(13.5, 4.2), sharey=True)
    all_latency = [float(row["latency_seconds"]) for scenario in scenarios for row in scenario_rows[scenario] if to_float(row.get("latency_seconds")) is not None]
    latency_norm = plt.Normalize(float(min(all_latency)), float(max(all_latency)))
    latency_cmap = plt.get_cmap("viridis_r")
    for ax, scenario in zip(axes, scenarios):
        rows = scenario_rows[scenario]
        # The paper's primary frontier is three-dimensional
        # (quality up, fee and E2E down).  This panel is its readable
        # quality-fee projection; latency remains encoded in membership.
        pareto_names = {r["model_name"] for r in rows if r.get("pareto_quality_cost_latency")}
        for row in rows:
            eligible = row.get("eligible_theta_025") in {True, "True"}
            latency = float(row["latency_seconds"])
            color = latency_cmap(latency_norm(latency))
            alpha = 0.9 if eligible or row["model_name"] == "Kimi K3 (max)" else 0.45
            is_frontier = row["model_name"] in pareto_names
            is_kimi = row["model_name"] == "Kimi K3 (max)"
            edge = "#d95f02" if is_kimi else ("#111111" if is_frontier else "white")
            linewidth = 1.4 if is_kimi else (1.1 if is_frontier else 0.3)
            ax.scatter(float(row["cost_usd_per_1000_tasks"]), float(row["performance"]), s=22 + min(float(row["speed_tokens_per_second"]), 350) / 12, color=color, alpha=alpha, edgecolors=edge, linewidths=linewidth)
            if row["model_name"] == "Kimi K3 (max)":
                # Keep the right-most panel label inside the plotting area.
                ax.annotate(
                    "Kimi K3",
                    (float(row["cost_usd_per_1000_tasks"]), float(row["performance"])),
                    xytext=(-5, 5),
                    textcoords="offset points",
                    ha="right",
                    fontsize=8,
                )
        ax.set_xscale("log")
        ax.set_title(scenario)
        ax.set_xlabel("每1000次任务成本（USD，对数轴）")
        ax.grid(True, which="both")
    axes[0].set_ylabel("场景综合得分")
    from matplotlib.lines import Line2D
    fig.legend(handles=[
        Line2D([0], [0], marker="o", linestyle="", markerfacecolor="#777", markeredgecolor="#111", label="黑边：三目标Pareto前沿", markersize=7),
        Line2D([0], [0], marker="o", linestyle="", markerfacecolor="#777", markeredgecolor="white", label="白边：其他配置", markersize=7),
        Line2D([0], [0], marker="o", linestyle="", markerfacecolor="#777", markeredgecolor="#d95f02", label="橙边：Kimi K3", markersize=7),
    ], loc="lower center", ncol=3, frameon=False, fontsize=7.5, bbox_to_anchor=(0.45, 0.025))
    sm = plt.cm.ScalarMappable(norm=latency_norm, cmap=latency_cmap)
    sm.set_array([])
    # A dedicated colorbar axis prevents the third panel, its x label and the
    # colorbar label from competing for the same lower-right area.
    cax = fig.add_axes([0.885, 0.22, 0.014, 0.60])
    fig.colorbar(sm, cax=cax, label="统一评测协议 E2E 时延代理（秒）")
    fig.suptitle("三目标 Pareto 前沿的场景综合得分–费用投影", fontsize=11, y=1.02)
    # Colorbar axes are not compatible with tight_layout on all Matplotlib
    # versions; use explicit margins so the legend and colorbar stay clear.
    fig.subplots_adjust(left=0.055, right=0.855, top=0.87, bottom=0.21, wspace=0.10)
    savefig_pair(fig, "fig09_pareto")
    # 10. Budget decision paths.  Each interval occupies a categorical model
    # row, so the graphic communicates both the switch point and the selected
    # configuration without slanted labels floating over score lines.
    fig, axes = plt.subplots(1, 3, figsize=(13.5, 4.6))
    short_labels = {
        "Nemotron 3.5 Lightning": "Nemo-Light",
        "Nemotron 3 Super": "Nemo-Super",
        "gpt-oss-120b (high)": "gpt-oss",
        "MiniMax-M3": "MiniMax-M3",
        "DeepSeek V4 Pro 0813 (max)": "DeepSeek V4",
        "GLM-5.2 (max)": "GLM-5.2",
        "Grok 4.6 (high)": "Grok 4.6",
        "Kimi K3 (max)": "Kimi K3",
        "GPT-5.6 Luna (max)": "GPT-Luna",
        "Gemini 3.5 Flash-Lite": "Gemini Flash-Lite",
        "Muse Glimmer (high)": "Muse Glimmer",
    }
    for ax, scenario in zip(axes, scenarios):
        rows = read_csv(RESULTS / f"q3_budget_segments_{scenario}.csv")
        if rows:
            normal_rows = [r for r in rows if r.get("score", "").strip()]
            min_cost = min((float(r["budget_lower_usd_per_1000"]) for r in normal_rows), default=1.0)
            last_start = max((float(r["budget_lower_usd_per_1000"]) for r in normal_rows), default=min_cost)
            left = max(min_cost * 0.58, 1e-3)
            right = max(last_start * 1.85, min_cost * 2.0)
            if rows and any(not r.get("score", "").strip() for r in rows):
                ax.axvspan(left, min_cost, color="#bdbdbd", alpha=0.22, zorder=0)
                ax.text(math.sqrt(left * min_cost), -0.42, "无可行", ha="center", va="center", fontsize=7, color="#666")
            for segment_index, row in enumerate(normal_rows):
                start = float(row["budget_lower_usd_per_1000"])
                end = row["budget_upper_usd_per_1000"]
                end_val = right if end == "inf" else float(end)
                y = segment_index
                ax.plot(
                    [start, end_val], [y, y],
                    color=SCENARIO_COLORS[scenario], linewidth=8,
                    solid_capstyle="butt", alpha=0.88, zorder=3,
                )
                ax.scatter([start], [y], s=34, facecolor="white", edgecolor=SCENARIO_COLORS[scenario], linewidth=1.4, zorder=4)
                text_x = math.sqrt(max(start, 1e-8) * max(end_val, 1e-8))
                ax.text(text_x, y + 0.16, f"S={float(row['score']):.3f}", ha="center", va="bottom", fontsize=7, color="#444")
                if segment_index + 1 < len(normal_rows):
                    next_start = float(normal_rows[segment_index + 1]["budget_lower_usd_per_1000"])
                    ax.plot([next_start, next_start], [y, y + 1], color=SCENARIO_COLORS[scenario], linewidth=1.2, alpha=0.45, zorder=2)
                    ax.axvline(next_start, color="#888", linewidth=0.6, linestyle=":", alpha=0.5, zorder=1)
            ax.set_xscale("log")
            switch_ticks = sorted({float(r["budget_lower_usd_per_1000"]) for r in normal_rows})
            ax.xaxis.set_major_locator(matplotlib.ticker.LogLocator(base=10.0, subs=(1.0,), numticks=4))
            ax.xaxis.set_minor_locator(matplotlib.ticker.NullLocator())
            ax.xaxis.set_major_formatter(matplotlib.ticker.LogFormatterMathtext(base=10.0))
            for tick in switch_ticks:
                ax.annotate(
                    f"B={tick:g}",
                    xy=(tick, 1),
                    xycoords=("data", "axes fraction"),
                    xytext=(2, -3),
                    textcoords="offset points",
                    ha="left",
                    va="top",
                    rotation=90,
                    fontsize=6.5,
                    color="#666",
                    annotation_clip=False,
                )
            ax.set_yticks(
                list(range(len(normal_rows))),
                [short_labels.get(r["recommended_model"], short_name(r["recommended_model"], 16)) for r in normal_rows],
            )
            ax.set_ylim(-0.55, len(normal_rows) - 0.35)
            ax.set_xlim(left, right)
        ax.set_title(scenario)
        ax.set_xlabel("预算 B（USD/1000次任务，对数轴）")
        ax.grid(True, axis="x", which="major", alpha=0.25)
        ax.grid(False, axis="y")
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
    axes[0].set_ylabel("推荐配置（随预算递进）")
    fig.suptitle("中等标准负载下的分段预算选型路径", fontsize=11, y=0.99)
    fig.tight_layout(rect=(0, 0, 1, 0.95), w_pad=2.0)
    savefig_pair(fig, "fig10_budget_switch")
    # 11. Cost-fit plots (observed points + selected curve approximated by
    # sorted fitted values from q3_fit_points.csv).
    fit_points = read_csv(RESULTS / "q3_fit_points.csv")
    fit_summary = read_csv(RESULTS / "q3_fit_summary.csv")
    fig, axes = plt.subplots(1, 3, figsize=(13.8, 4.6), sharey=True)
    for ax, scenario in zip(axes, scenarios):
        base = [r for r in scenario_rows[scenario] if r.get("eligible_theta_025") in {True, "True"}]
        ax.scatter([float(r["cost_usd_per_1000_tasks"]) for r in base], [float(r["performance"]) for r in base], color="#47759d", s=26, alpha=0.82, label="观测配置")
        selected = next((r["model"] for r in fit_summary if r["scenario"] == scenario and r.get("selected") in {True, "True"}), None)
        if selected:
            pts = [r for r in fit_points if r["scenario"] == scenario and r["model"] == selected]
            pts.sort(key=lambda r: float(r["cost_usd_per_1000_tasks"]))
            selected_row = next(r for r in fit_summary if r["scenario"] == scenario and r["model"] == selected)
            ax.plot([float(r["cost_usd_per_1000_tasks"]) for r in pts], [float(r["fitted_performance"]) for r in pts], color="#d95f02", linewidth=1.8, label=f"选择：{selected}")
            ax.text(0.03, 0.96, f"函数：{selected}\nR²={float(selected_row['r2']):.2f}\nLOOCV={float(selected_row['loocv_rmse']):.3f}", transform=ax.transAxes, va="top", fontsize=7.5, bbox=dict(facecolor="white", alpha=0.72, edgecolor="none", pad=2))
        ax.set_xscale("log")
        # The daily panel is narrow enough that the default minor log labels
        # (2×10^0, 3×10^0, ...) collide.  Keep only sparse powers of ten.
        ax.xaxis.set_major_locator(matplotlib.ticker.LogLocator(base=10.0, subs=(1.0,), numticks=5))
        ax.xaxis.set_minor_locator(matplotlib.ticker.NullLocator())
        ax.xaxis.set_major_formatter(matplotlib.ticker.LogFormatterMathtext(base=10.0))
        ax.set_title(scenario)
        ax.set_xlabel("每1000次任务成本（USD）")
        ax.grid(True, which="both")
        ax.legend(frameon=False, fontsize=7)
    axes[0].set_ylabel("场景综合得分")
    fig.tight_layout()
    savefig_pair(fig, "fig11_cost_fit")
    # 12. Four-criterion view: performance up, direct fee/E2E/compute burden
    # down.  Colour encodes fee, while the multicriteria frontier is outlined.
    fig, axes = plt.subplots(1, 3, figsize=(13.0, 4.0), sharey=True)
    for ax, scenario in zip(axes, scenarios):
        rows = scenario_rows[scenario]
        finite_rows = [r for r in rows if to_float(r.get("compute_burden_tokens_mean")) is not None]
        if finite_rows:
            costs = np.asarray([float(r["cost_usd_per_1000_tasks"]) for r in finite_rows])
            norm = plt.Normalize(float(np.min(costs)), float(np.max(costs)))
            cmap = plt.get_cmap("viridis")
            frontier = {r["model_name"] for r in rows if r.get("pareto_multi_performance_fee_latency_compute") in {True, "True"}}
            for row in finite_rows:
                color = "#d95f02" if row["model_name"] == "Kimi K3 (max)" else cmap(norm(float(row["cost_usd_per_1000_tasks"])))
                edge = "#111" if row["model_name"] in frontier else "white"
                ax.scatter(float(row["compute_burden_tokens_mean"]), float(row["performance"]), color=color, edgecolors=edge, linewidths=1.1, s=34, alpha=0.9)
                if row["model_name"] == "Kimi K3 (max)":
                    ax.annotate("Kimi K3", (float(row["compute_burden_tokens_mean"]), float(row["performance"])), xytext=(4, 4), textcoords="offset points", fontsize=8)
            ax.set_xscale("log")
            sm = plt.cm.ScalarMappable(norm=norm, cmap=cmap)
            sm.set_array([])
            fig.colorbar(sm, ax=ax, fraction=0.046, pad=0.04, label="成本（场景内比较）")
        ax.set_title(scenario)
        ax.set_xlabel("AA任务平均输出token数（计算负担代理）")
        ax.grid(True, which="both")
    axes[0].set_ylabel("场景综合得分")
    from matplotlib.lines import Line2D
    axes[0].legend(handles=[Line2D([0], [0], marker="o", color="white", markerfacecolor="#777", markeredgecolor="#111", label="黑边：多目标Pareto前沿", markersize=7), Line2D([0], [0], marker="o", color="white", markerfacecolor="#777", markeredgecolor="white", label="白边：其他配置", markersize=7)], frameon=False, fontsize=7, loc="lower right")
    fig.tight_layout()
    savefig_pair(fig, "fig12_compute_pareto")
    # 13. Compact validation dashboard.  Each panel corresponds to one
    # distinct evidence layer: scale sensitivity, capability leave-one-out,
    # latency-grid feasibility, and Monte-Carlo Pareto membership.
    fig, axes = plt.subplots(2, 2, figsize=(12.0, 9.0))
    ax = axes[0, 0]
    std_rows = read_csv(RESULTS / "robustness_standardization_equal_weight.csv")
    std_label_map = {"分位数（主模型）": "分位数", "Min-Max": "Min-Max", "Robust-Z（中位数/IQR）": "Robust-Z"}
    std_labels = [std_label_map.get(r["variant"], r["variant"]) for r in std_rows]
    std_tau = [float(r["kendall_tau"]) for r in std_rows]
    std_top5 = [float(r["top5_overlap"]) for r in std_rows]
    xx = np.arange(len(std_rows)); width = 0.36
    ax.bar(xx - width / 2, std_tau, width, label="Kendall τ", color="#47759d")
    ax.bar(xx + width / 2, std_top5, width, label="Top5重合率", color="#9ecae1")
    ax.set_ylim(0, 1.08); ax.set_xticks(xx, std_labels); ax.set_ylabel("一致性指标"); ax.set_title("(a) 标准化方法一致性"); ax.legend(frameon=False, fontsize=8)
    for x0, value in zip(xx - width / 2, std_tau): ax.text(x0, value + 0.025, f"{value:.2f}", ha="center", fontsize=7)
    ax.grid(axis="y")

    ax = axes[0, 1]
    loco = [r for r in read_csv(RESULTS / "robustness_leave_one_ability_summary.csv") if r.get("scenario") == "通用"]
    loco.sort(key=lambda r: ABILITIES.index(r["dropped_ability"]))
    vals = [int(r["kimi_rank"]) for r in loco]
    bars = ax.bar([r["dropped_ability"] for r in loco], vals, color="#d95f02")
    ax.set_ylim(max(vals) + 1, 0.5); ax.set_ylabel("Kimi K3 名次"); ax.set_title("(b) 留一能力维度：Kimi 名次"); ax.grid(axis="y")
    for bar, value in zip(bars, vals): ax.text(bar.get_x() + bar.get_width() / 2, value - 0.18, str(value), ha="center", va="top", fontsize=8, color="white")

    ax = axes[1, 0]
    lat_rows = read_csv(RESULTS / "q3_latency_threshold_summary.csv")
    c_offsets = {"科研长文本": (0, 8), "大众日常对话": (12, -18), "计算机代码开发": (8, 10)}
    c_short_names = {
        "Gemini 3.5 Flash-Lite": "Gemini Lite",
        "Muse Glimmer (high)": "Muse Glimmer",
        "MiniMax-M3": "MiniMax-M3",
        "GPT-5.6 Luna (max)": "GPT-5.6 Luna",
        "GLM-5.2 (max)": "GLM-5.2",
        "Grok 4.6 (high)": "Grok 4.6",
        "Kimi K3 (max)": "Kimi K3",
        "Claude Opus 5 (max)": "Claude Opus",
    }
    for scenario in SCENARIOS:
        rows = [r for r in lat_rows if r["scenario"] == scenario]
        ax.plot([float(r["latency_threshold_seconds"]) for r in rows], [int(r["feasible_count"]) for r in rows], marker="o", linewidth=1.8, label=scenario)
        last_first_recommendation = None
        for index, r in enumerate(rows):
            seq = r["recommended_sequence"]
            first_recommendation = seq.split(" -> ")[0] if seq and seq != "无可行模型" else "—"
            # Only annotate a change in the first recommendation.  Later
            # changes in the complete budget sequence remain in the CSV table
            # and do not overcrowd this compact figure.
            if first_recommendation != last_first_recommendation:
                short = c_short_names.get(first_recommendation, first_recommendation.replace(" (max)", ""))
                x_offset, y_offset = c_offsets[scenario]
                is_left_edge = index == 0
                ax.annotate(short, (float(r["latency_threshold_seconds"]), int(r["feasible_count"])), textcoords="offset points", xytext=(x_offset, y_offset + 7 * (index % 2)), ha="left" if is_left_edge else "center", fontsize=7, annotation_clip=False)
            last_first_recommendation = first_recommendation
    ax.set_xlabel("统一协议 E2E 时延代理边界（秒）"); ax.set_ylabel("I_is(0.25)可行配置数"); ax.set_title("(c) 时延代理边界：可行集与推荐切换"); ax.legend(frameon=False, fontsize=7); ax.grid(True)

    ax = axes[1, 1]
    mc_rows = read_csv(RESULTS / "robustness_pareto_monte_carlo.csv")
    top_models = []
    for scenario in SCENARIOS:
        candidates = sorted([r for r in mc_rows if r["scenario"] == scenario], key=lambda r: -float(r["pareto_stable_frequency"]))[:4]
        top_models.extend([r["model_name"] for r in candidates])
    top_models = list(dict.fromkeys(top_models))
    validation_short_names = {
        "GLM-5.2 (max)": "GLM-5.2",
        "MiniMax-M3": "MiniMax-M3",
        "Gemini 3.5 Flash-Lite": "Gemini Lite",
        "Kimi K3 (max)": "Kimi K3",
        "Muse Glimmer (high)": "Muse Glimmer",
        "Grok 4.6 (high)": "Grok 4.6",
        "Claude Opus 5 (max)": "Claude Opus",
        "GPT-5.6 Sol (max)": "GPT-5.6 Sol",
    }
    x = np.arange(len(top_models)); width = 0.24
    for idx, scenario in enumerate(SCENARIOS):
        lookup = {r["model_name"]: float(r["pareto_stable_frequency"]) for r in mc_rows if r["scenario"] == scenario}
        ax.bar(x + (idx - 1) * width, [lookup.get(name, 0.0) for name in top_models], width, label=scenario, color=SCENARIO_COLORS[scenario])
    ax.set_ylim(0, 1.08); ax.set_xticks(x, [validation_short_names.get(n, n) for n in top_models], rotation=20, ha="right", fontsize=8); ax.set_ylabel("Pareto稳定频率"); ax.set_title("(d) Monte Carlo Pareto 稳定频率"); ax.legend(frameon=False, fontsize=7, ncol=3, loc="upper center", bbox_to_anchor=(0.5, -0.18)); ax.grid(axis="y")
    fig.suptitle("模型检验、敏感性与稳健性摘要", fontsize=13, y=0.995)
    fig.tight_layout(rect=[0.02, 0.04, 0.98, 0.96])
    savefig_pair(fig, "fig13_validation_summary")
    write_json(RESULTS / "figure_metadata.json", {
        "fig01_method_flow": {"third_box": "七项核心评价维度与通用无偏好权重"},
        "fig05_overall_ranking": {"title": "27个配置中的通用综合得分前12名", "x_label": "通用综合得分（相对分位评价）"},
        "fig07_scenario_ranking": {"title": "27个配置中的三类场景前五名"},
        "fig06_kimi_profile": {"x_label": "C1-C7核心评价维度", "y_label": "相对分位得分", "c3_label": "知识边界校准"},
        "fig09_pareto": {
            "title": "三目标 Pareto 前沿的场景综合得分–费用投影",
            "x_label": "每1000次任务成本（USD，对数轴）",
            "y_label": "场景综合得分",
            "color": "统一评测协议 E2E 时延代理（秒）",
            "caption": "Pareto 集按场景综合得分、直接费用与统一协议 E2E 时延三目标确定；图中仅投影到场景综合得分–费用平面。",
        },
        "fig12_compute_pareto": {"y_label": "场景综合得分"},
    })


def validate_outputs(names: Sequence[str], raw: np.ndarray, api_by_model: Mapping[str, Mapping[str, str]], scenario_rows: Mapping[str, Sequence[Mapping[str, object]]]) -> dict[str, object]:
    proxy_rows = read_csv(RESULTS / "compute_proxy.csv") if (RESULTS / "compute_proxy.csv").exists() else []
    q3_gate = {
        scenario: {row["model_name"]: row.get("eligible_theta_025") in {True, "True"} for row in rows}
        for scenario, rows in scenario_rows.items()
    }
    pareto_gate_ok = all(
        all(q3_gate[scenario].get(row["model_name"], False) for row in read_csv(RESULTS / f"q3_pareto_{scenario}.csv"))
        and all(q3_gate[scenario].get(row["model_name"], False) for row in read_csv(RESULTS / f"q3_pareto_quality_cost_latency_{scenario}.csv"))
        for scenario in SCENARIOS
    )
    budget_gate_ok = True
    for scenario in SCENARIOS:
        for suffix in ("", "_light", "_medium", "_heavy"):
            rows = read_csv(RESULTS / f"q3_budget_segments_{scenario}{suffix}.csv")
            for row in rows:
                model = row.get("recommended_model", "")
                if model and model != "无可行模型" and not q3_gate[scenario].get(model, False):
                    budget_gate_ok = False
    fit_gate_ok = all(
        q3_gate[row["scenario"]].get(row["model_name"], False)
        for row in read_csv(RESULTS / "q3_fit_points.csv")
    )
    required_v3 = [
        "all_high_corr_pairs.csv",
        "scenario_task_matrix.csv",
        "robustness_standardization_equal_weight.csv", "coverage_threshold_sensitivity.csv", "coverage_threshold_admission.csv",
        "robustness_model_family.csv", "robustness_model_family_summary.csv", "q3_latency_threshold_summary.csv", "q3_latency_threshold_segments.csv",
        "q3_cache_sensitivity_costs_long.csv", "q3_cache_sensitivity_pareto.csv", "q3_cache_sensitivity_budget_segments.csv", "q3_cache_sensitivity_summary.csv",
        "robustness_pareto_monte_carlo.csv", "q3_pareto_monte_carlo_summary.csv", "robustness_pareto_monte_carlo_config.json", "q3_fit_leave_one_model_out.csv", "q3_fit_leave_one_model_out_summary.csv",
        "q3_workload_pareto_stability.csv",
    ]
    v3_files_complete = all((RESULTS / filename).exists() and (RESULTS / filename).stat().st_size > 0 for filename in required_v3)
    main_rank_rows = read_csv(RESULTS / "rankings.csv")
    main_top5_unchanged = all(
        tuple(row["model_name"] for row in sorted(main_rank_rows, key=lambda r: float(r[f"{key}_rank"]))[:5]) == expected
        for key, expected in FROZEN_MAIN_TOP5.items()
    )
    std_rows = read_csv(RESULTS / "robustness_standardization_equal_weight.csv")
    std_variants_ok = {r["variant"] for r in std_rows} == {"分位数（主模型）", "Min-Max", "Robust-Z（中位数/IQR）"} and all(0 <= float(r["top5_overlap"]) <= 1 and -1 <= float(r["kendall_tau"]) <= 1 and -1 <= float(r["spearman_rho"]) <= 1 for r in std_rows)
    coverage_summary = read_csv(RESULTS / "coverage_threshold_sensitivity.csv")
    coverage_thresholds_ok = {float(r["threshold"]) for r in coverage_summary} == {0.60, 0.70, 0.80, 0.90} and all(is_true(r["no_extension_imputation"]) and is_true(r["core_set_same_as_main"]) for r in coverage_summary)
    latency_summary = read_csv(RESULTS / "q3_latency_threshold_summary.csv")
    latency_thresholds_ok = all({float(r["latency_threshold_seconds"]) for r in latency_summary if r["scenario"] == scenario} == set(LATENCY_THRESHOLDS[scenario]) for scenario in SCENARIOS)
    latency_rec_ok = True
    for row in read_csv(RESULTS / "q3_latency_threshold_segments.csv"):
        model = row.get("recommended_model", "")
        if model and model != "无可行模型":
            scen = row["scenario"]
            if not q3_gate[scen].get(model, False): latency_rec_ok = False
            api = api_by_model.get(model, {})
            if to_float(api.get("e2e_seconds")) is None or float(api["e2e_seconds"]) > float(row["latency_threshold_seconds"]) + 1e-9: latency_rec_ok = False
    cache_rows = read_csv(RESULTS / "q3_cache_sensitivity_costs_long.csv")
    cache_rates_ok = {float(r["h_cache"]) for r in cache_rows} == set(CACHE_HIT_RATES) and all(int(float(r["cache_panel_size"])) == 19 for r in cache_rows)
    cache_rec_ok = True
    for row in read_csv(RESULTS / "q3_cache_sensitivity_budget_segments.csv"):
        model = row.get("recommended_model", "")
        if model and model != "无可行模型":
            scenario = row["scenario"]
            if not q3_gate[scenario].get(model, False):
                cache_rec_ok = False
            api = api_by_model.get(model, {})
            if to_float(api.get("e2e_seconds")) is None or float(api["e2e_seconds"]) > WORKLOADS[scenario]["latency_limit"] + 1e-9:
                cache_rec_ok = False
    mc_rows = read_csv(RESULTS / "robustness_pareto_monte_carlo.csv")
    mc_prob_ok = len(mc_rows) == len(names) * len(SCENARIOS) and all(0 <= float(r["pareto_stable_frequency"]) <= 1 and 0 <= int(r["pareto_hits"]) <= V3_MONTE_CARLO_DRAWS and int(r["draws"]) == V3_MONTE_CARLO_DRAWS and int(r["seed"]) == V3_SEED for r in mc_rows)
    mc_summary_rows = read_csv(RESULTS / "q3_pareto_monte_carlo_summary.csv")
    mc_summary_ok = len(mc_summary_rows) == len(SCENARIOS)
    if mc_summary_ok:
        for summary_row in mc_summary_rows:
            scenario = summary_row["scenario"]
            long_rows = [row for row in mc_rows if row["scenario"] == scenario]
            total_hits = sum(int(row["pareto_hits"]) for row in long_rows)
            max_hits = max(int(row["pareto_hits"]) for row in long_rows)
            max_models = sorted(row["model_name"] for row in long_rows if int(row["pareto_hits"]) == max_hits)
            listed_models = sorted(filter(None, summary_row["max_frequency_models"].split(";")))
            mc_summary_ok = mc_summary_ok and math.isclose(float(summary_row["mean_frontier_size"]), total_hits / V3_MONTE_CARLO_DRAWS, abs_tol=1e-12) and math.isclose(float(summary_row["max_frequency"]), max_hits / V3_MONTE_CARLO_DRAWS, abs_tol=1e-12) and listed_models == max_models and int(summary_row["total_frontier_memberships"]) == total_hits and int(summary_row["draws"]) == V3_MONTE_CARLO_DRAWS
    family_summary = read_csv(RESULTS / "robustness_model_family_summary.csv")
    family_ok = bool(family_summary) and all("厂商代表层" in row["comparison_scope"] and int(row["vendor_count"]) > 1 for row in family_summary)
    lomo_summary = read_csv(RESULTS / "q3_fit_leave_one_model_out_summary.csv")
    lomo_ok = len(lomo_summary) == len(SCENARIOS) and all(0 <= float(row["same_function_rate"]) <= 1 for row in lomo_summary)
    workload_stability_rows = read_csv(RESULTS / "q3_workload_pareto_stability.csv")
    expected_workload_frontier_sizes = {"科研长文本": 6, "大众日常对话": 5, "计算机代码开发": 7}
    workload_stability_ok = (
        len(workload_stability_rows) == 2 * len(SCENARIOS)
        and all(
            row.get("frontier_type") == "quality_cost_latency_3d"
            and int(row["medium_frontier_size"]) == expected_workload_frontier_sizes[row["scenario"]]
            and int(row["other_frontier_size"]) == expected_workload_frontier_sizes[row["scenario"]]
            and math.isclose(float(row["jaccard_frontier"]), 1.0, abs_tol=1e-12)
            for row in workload_stability_rows
        )
    )
    scenario_task_matrix_rows = read_csv(RESULTS / "scenario_task_matrix.csv")
    scenario_task_matrix_ok = len(scenario_task_matrix_rows) == 5 * len(SCENARIOS)
    seen_task_keys: set[tuple[str, int]] = set()
    if scenario_task_matrix_ok:
        for row in scenario_task_matrix_rows:
            try:
                scenario = row["scenario"]
                task_id = int(float(row["task_id"]))
                key = (scenario, task_id)
                expected = TASK_DEPENDENCY[scenario][task_id - 1]
                scenario_task_matrix_ok = scenario_task_matrix_ok and (
                    scenario in SCENARIOS
                    and 1 <= task_id <= 5
                    and key not in seen_task_keys
                    and row.get("task_name", "") == TASK_NAMES[scenario][task_id - 1]
                    and math.isclose(float(row.get("task_importance", "nan")), 0.2, abs_tol=1e-12)
                    and all(int(float(row[ability])) == int(expected[j]) for j, ability in enumerate(ABILITIES))
                )
                seen_task_keys.add(key)
            except (KeyError, IndexError, TypeError, ValueError):
                scenario_task_matrix_ok = False
    scenario_task_matrix_ok = scenario_task_matrix_ok and len(seen_task_keys) == 5 * len(SCENARIOS)
    high_corr_rows = read_csv(RESULTS / "all_high_corr_pairs.csv")
    spearman_rows = read_csv(RESULTS / "spearman_pairs.csv")
    high_corr_expected = sum(float(row["spearman_rho"]) >= 0.85 for row in spearman_rows)
    metadata_path = RESULTS / "correlation_metadata.json"
    correlation_metadata = json.loads(metadata_path.read_text(encoding="utf-8")) if metadata_path.exists() else {}
    high_corr_review_ok = (
        len(high_corr_rows) == high_corr_expected
        and all(all(row.get(field, "").strip() for field in ("benchmark_a", "benchmark_b", "construct_a", "construct_b", "constructs_highly_overlapping", "substantive_redundancy", "final_treatment", "treatment_reason")) for row in high_corr_rows)
        and correlation_metadata.get("linkage_method") == "average"
    )
    checks = {
        "quality_panel_count_is_27": len(names) == 27,
        "all_8_quality_indicators_complete": bool(np.all(np.isfinite(raw))),
        "kimi_k3_retained": "Kimi K3 (max)" in names,
        "q3_model_count_is_20": all(len(rows) == 20 for rows in scenario_rows.values()),
        "command_a_plus_excluded_from_q3": all("Command A+" not in {r["model_name"] for r in rows} for rows in scenario_rows.values()),
        "nemotron_3_super_retained_in_q3": all("Nemotron 3 Super" in {r["model_name"] for r in rows} for rows in scenario_rows.values()),
        "q3_positive_token_prices": all(float(r["input_price_usd_per_1m_tokens"]) > 0 and float(r["output_price_usd_per_1m_tokens"]) > 0 for rows in scenario_rows.values() for r in rows),
        "q3_cache_hit_rate_is_zero": all(float(r["h_cache"]) == 0 for rows in scenario_rows.values() for r in rows),
        "no_nan_or_infinite_q3_cost": all(math.isfinite(float(r["cost_usd_per_1000_tasks"])) for rows in scenario_rows.values() for r in rows),
        "q3_recommendations_all_eligible": pareto_gate_ok and budget_gate_ok,
        "all_lmh_budget_recommendations_eligible": budget_gate_ok,
        "q3_fit_samples_all_eligible": fit_gate_ok,
        "q3_primary_pareto_quality_cost_e2e": all((RESULTS / f"q3_pareto_quality_cost_latency_{scenario}.csv").exists() for scenario in SCENARIOS),
        "compute_proxy_file_present": len(proxy_rows) == 27,
        "compute_proxy_is_two_of_eight_exploratory": bool(proxy_rows) and all(int(float(row["reliable_benchmark_count"])) == 2 and abs(float(row["core_benchmark_coverage_over_8"]) - 0.25) < 1e-12 for row in proxy_rows),
        "generic_weight_sum_is_one": math.isclose(float(np.sum(np.full(7, 1 / 7))), 1.0, abs_tol=1e-12),
        "scenario_weight_sums_are_one": all(math.isclose(float(np.sum([float(row["weight"]) for row in read_csv(RESULTS / "scenario_weights.csv") if row["weight_set"] == scenario])), 1.0, abs_tol=1e-6) for scenario in ["问题一通用", *SCENARIOS]),
        "speed_e2e_not_in_quality_matrix": raw.shape[1] == 8 and not any(item["id"] in {"Speed", "E2E"} for item in INDICATORS),
        "no_stale_critic_output": not (RESULTS / "critic_weights.csv").exists(),
        "compute_proxy_is_not_absolute_energy": True,
        "seed_fixed": SEED == 20260817,
        "v3_required_files_complete": v3_files_complete,
        "main_top5_rankings_unchanged": main_top5_unchanged,
        "standardization_three_methods_and_ranges": std_variants_ok,
        "coverage_thresholds_60_70_80_90_same_complete_core": coverage_thresholds_ok,
        "latency_threshold_grid_complete": latency_thresholds_ok,
        "latency_recommendations_gate_and_threshold_valid": latency_rec_ok,
        "cache_sensitivity_uses_19_positive_cache_configs": cache_rates_ok,
        "cache_recommendations_gate_valid": cache_rec_ok,
        "monte_carlo_pareto_probabilities_valid": mc_prob_ok,
        "monte_carlo_summary_matches_long_table": mc_summary_ok,
        "model_family_representative_comparison_valid": family_ok,
        "leave_one_model_out_fit_valid": lomo_ok,
        "workload_stability_uses_three_objective_frontier": workload_stability_ok,
        "scenario_task_matrix_matches_frozen_task_chains": scenario_task_matrix_ok,
        "high_corr_pairs_review_complete": high_corr_review_ok,
        "validation_summary_figure_complete": all((FIGURES / f"fig13_validation_summary.{ext}").exists() for ext in ("png", "svg", "pdf")),
    }
    result = {"checks": checks, "passed": all(checks.values()), "scope": "workstreams/analysis_engine", "generated_at": datetime.now(timezone.utc).isoformat(), "python": sys.version, "platform": platform.platform()}
    write_json(RESULTS / "validation.json", result)
    lines = ["# 分析工程验证记录", "", f"生成时间（UTC）：{result['generated_at']}", f"基础分析固定随机种子：{SEED}；Monte Carlo 固定随机种子：{V3_SEED}", "", "## 检查结果", ""]
    for key, value in checks.items():
        lines.append(f"- [{'x' if value else ' '}] {key}")
    lines += ["", "## 数据边界", "", "- 质量层使用八项核心 Benchmark 完整的 27 个配置；C1 为 HLE/GPQA 等权，C2 为知识正确性，C3 为知识边界校准（底层 Non-Hallucination 指标），其余维度分列。速度和端到端时延不进入质量矩阵。", "- 场景需求严格来自 MODEL_SPEC_V2.md 的五任务链，任务重要度均为 0.2；场景排序使用场景综合得分 S_is，I_is(0.25) 仅标记相对短板资格。", "- 问题三固定 h=0，成本只使用输入/输出 token 单价；仅纳入 20 个正价且工程字段完整的配置，Command A+不解释为免费。缓存敏感性另在 19 个正缓存价子样本上运行。", "- 问题三 Pareto 与预算路径使用 I_is(0.25) 资格配置的场景综合得分 S_is、直接费用和统一评测协议 E2E 时延代理三目标；T 仅作为工程响应效率代理，不解释为本文指定工作负载下的响应时间。", "- 覆盖率敏感性只改变理论候选准入诊断；低覆盖扩展指标不插值、不进入 27 配置主矩阵。", "- 工作负载 Pareto 稳定性采用质量、直接费用和统一协议 E2E 时延代理三目标前沿（frontier_type=quality_cost_latency_3d）；科研、日常、代码中等负载前沿规模分别为 6、5、7，轻/重负载 Jaccard 均为 1。", "- Monte Carlo Pareto 稳定频率固定 N=5000、seed=20261120、κ=100；从既有 L/M/H 三档和每场景四档统一协议 E2E 时延代理边界等概率抽样，分母始终为全部 5000 次。", "- 闭源配置没有统一功率、硬件和运行时间观测，不能推出统一口径的电力消耗量；代理指标不是 kWh。", "- `all_high_corr_pairs.csv` 枚举全部 rho≥0.85 的指标组合；高相关仅提出潜在冗余候选，最终处理结合构念、覆盖率、区分度和来源可靠性。", "- `scenario_task_matrix.csv` 保存三类场景各五项任务的 C1—C7 依赖编码和任务重要度，作为场景权重的可复核输入。", "- `results/V2_RESULTS_REPORT.md`（V3 检验版）摘录了前五排名、Kimi 数值、资格计数、预算节点与三层检验数值。", "", "## 视觉检查", "", "运行后应直接查看 `results/figures/*.png`；PNG 用于可视检查，论文优先使用同名 SVG/PDF 矢量文件。"]
    (OUT / "VALIDATION.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return result


def write_results_report(names: Sequence[str], analysis: Mapping[str, object], scenario_rows: Mapping[str, Sequence[Mapping[str, object]]], validation: Mapping[str, object]) -> None:
    """Write the compact, paper-ready numerical handoff for the V2 engine."""
    def f(value: object, digits: int = 6) -> str:
        return f"{float(value):.{digits}f}"

    lines = [
        "# V3 官方分析引擎结果摘录",
        "",
        "本文件由 `src/analyze.py` 生成，仅摘录可直接进入论文的口径和数值；完整逐模型结果见同目录 CSV。",
        "",
        "## 面板与模型口径",
        "",
        f"- 质量评价面板：{len(names)} 个配置；八项核心 Benchmark 均完整。工程评价正价且字段完整面板：{len(next(iter(scenario_rows.values())))} 个配置。",
        "- C1 为 HLE 与 GPQA Diamond 等权平均；C2 为知识正确性，C3 为知识边界校准（底层 Non-Hallucination 指标），C4—C7 为长文本、代码与科学计算、软件工程与工具执行、指令交互与任务完成的透明映射。",
        "- 问题一七项核心评价维度等权；问题二使用 MODEL_SPEC_V2.md 的五任务链，任务重要度均为 0.2。场景名次采用场景综合得分 S_is，I_is(0.25) 只标记相对短板资格集合。",
        "- 问题三的主 Pareto 与预算路径只在 I_is(0.25) 资格集合内使用场景综合得分 S_is、直接 token 费用和统一评测协议 E2E 时延代理三目标；T 不等同于本文工作负载下的场景响应时间。",
        "- Spearman 以 rho≥0.85 提出潜在冗余候选，距离 d=1-rho 后采用 average linkage 作相关结构诊断；全部高相关组合的构念审查见 `all_high_corr_pairs.csv`，不由相关性自动删除指标。",
        "",
        "## 任务链需求与场景权重",
        "",
        "三类场景各五项任务的逐任务依赖矩阵见 `scenario_task_matrix.csv`；任务重要度均为 0.2，C1—C7 数值直接来自冻结的 TASK_DEPENDENCY。",
        "| 场景 | " + " | ".join(ABILITIES) + " |",
        "|---|" + "---:|" * len(ABILITIES),
    ]
    for scenario in SCENARIOS:
        demand = [SCENARIO_DEMAND[scenario][a] for a in ABILITIES]
        weights = np.asarray(analysis["weights"][scenario], dtype=float)
        lines.append(f"| {scenario}需求 | " + " | ".join(f(x, 3) for x in demand) + " |")
        lines.append(f"| {scenario}权重 | " + " | ".join(f(x, 6) for x in weights) + " |")
    lines += [
        "",
        "## 问题一与问题二排名（前五）",
        "",
        "| 评价口径 | 1 | 2 | 3 | 4 | 5 |",
        "|---|---|---|---|---|---|",
    ]
    for key, label in [("问题一通用", "问题一通用"), *[(s, s) for s in SCENARIOS]]:
        order = np.argsort(-np.asarray(analysis["scores"][key], dtype=float))[:5]
        top = [f"{names[i]}（{f(analysis['scores'][key][i], 6)}）" for i in order]
        lines.append(f"| {label} | " + " | ".join(top) + " |")
    kimi_index = list(names).index("Kimi K3 (max)")
    lines += [
        "",
        "### Kimi K3 关键数值",
        "",
        f"- 通用：得分 {f(analysis['scores']['问题一通用'][kimi_index])}，名次 {int(analysis['ranks']['问题一通用'][kimi_index])}/{len(names)}。",
    ]
    for scenario in SCENARIOS:
        lines.append(f"- {scenario}：场景综合得分 S_is {f(analysis['scores'][scenario][kimi_index])}，名次 {int(analysis['ranks'][scenario][kimi_index])}/{len(names)}；I_is(0.25) 相对短板资格{'通过' if analysis['eligibility'][scenario][0.25][kimi_index] else '未通过'}。")
    lines += ["", "## 相对短板资格与覆盖率", "", "| 场景 | I_is(0.20) | I_is(0.25) | I_is(0.30) | 问题三正价样本中 I_is(0.25) |", "|---|---:|---:|---:|---:|"]
    for scenario in SCENARIOS:
        all_counts = [int(np.sum(analysis["eligibility"][scenario][theta])) for theta in (0.20, 0.25, 0.30)]
        q3_count = sum(row.get("eligible_theta_025") in {True, "True"} for row in scenario_rows[scenario])
        lines.append(f"| {scenario} | {all_counts[0]} | {all_counts[1]} | {all_counts[2]} | {q3_count}/{len(scenario_rows[scenario])} |")
    coverage_rows = read_csv(RESULTS / "coverage_admission.csv")
    core = [row for row in coverage_rows if row.get("panel_size") == "27" and row.get("panel_role") == "core"]
    ext = [row for row in coverage_rows if row.get("panel_size") == "27" and row.get("panel_role") != "core"]
    lines.append(f"- 27 配置核心八项 Benchmark 在 60%/70%/80%/90% 四个准入阈值下均为全量通过（{len({row['benchmark'] for row in core})} 项核心指标）。")
    if ext:
        by_threshold = {threshold: sum(row.get("admitted_candidate") in {True, "True"} for row in ext if row.get("threshold") == str(threshold)) for threshold in (0.60, 0.70, 0.80, 0.90)}
        lines.append(f"- 扩展指标只作为覆盖率诊断；27 配置面板下 60%/70%/80%/90% 分别通过 {by_threshold[0.60]}/{by_threshold[0.70]}/{by_threshold[0.80]}/{by_threshold[0.90]} 条，不补齐主评价矩阵。")
    lines += ["", "## 问题三中等负载的可复核价格节点", "", "| 场景 | Kimi K3 中等负载直接费用（USD/1000任务） | 主预算路径首个可行推荐 |", "|---|---:|---|"]
    for scenario in SCENARIOS:
        kimi_row = next(row for row in scenario_rows[scenario] if row["model_name"] == "Kimi K3 (max)")
        segments = read_csv(RESULTS / f"q3_budget_segments_{scenario}.csv")
        first = next((row["recommended_model"] for row in segments if row.get("recommended_model") not in {"", "无可行模型"}), "无可行模型")
        lines.append(f"| {scenario} | {f(kimi_row['cost_usd_per_1000_tasks'], 3)} | {first} |")
    lines += [
        "",
        "## 稳健性摘要",
        "",
        "Dirichlet 采样使用 10,000 次、浓度参数 κ=100；报告 Top1/Top3 概率、平均名次和名次标准差。",
    ]
    dir_rows = read_csv(RESULTS / "robustness_dirichlet_rank.csv")
    for scheme, scenario, label in [("Dirichlet-通用权重", "通用", "通用"), ("Dirichlet-场景直接", "科研长文本", "科研长文本"), ("Dirichlet-场景直接", "大众日常对话", "大众日常对话"), ("Dirichlet-场景直接", "计算机代码开发", "计算机代码开发")]:
        candidates = [row for row in dir_rows if row.get("scheme") == scheme and row.get("scenario") == scenario]
        if not candidates:
            continue
        best = sorted(candidates, key=lambda row: (-float(row["top1_probability"]), float(row["mean_rank"])))[:1][0]
        lines.append(f"- {label}：Top1 最高为 {best['model_name']}，概率 {f(best['top1_probability'])}；Top3 {f(best['top3_probability'])}；平均名次 {f(best['mean_rank'], 4)}，名次标准差 {f(best['rank_std'], 4)}。")
    pm_rows = read_csv(RESULTS / "robustness_demand_pm20.csv")
    lines.append("- 任务需求±20% 的 Top1 结果、leave-one Benchmark/ability、标准化替换结果详见对应 CSV；这些检验用于报告结论对设定的敏感性，不把机械不变的前沿误写成普适规律。")
    lines += ["", "## V3 模型检验、敏感性与稳健性", "", "- 敏感性分析改变覆盖率准入、场景需求、工作负载、统一协议 E2E 时延代理边界、缓存命中率和预算等参数；结构稳健性使用标准化替换、TOPSIS、留一 Benchmark、留一能力、模型家族代表；不确定性分析使用 Dirichlet/需求随机扰动与固定种子的 Monte Carlo。"]
    std_rows = read_csv(RESULTS / "robustness_standardization_equal_weight.csv")
    lines.append("- 标准化对照：" + "；".join(f"{r['variant']} Kendall={float(r['kendall_tau']):.3f}、Spearman={float(r['spearman_rho']):.3f}、Top5={float(r['top5_overlap']):.0%}、Kimi={r['kimi_rank']}" for r in std_rows) + "。Robust-Z 严格按 (x−median)/IQR 计算，仅作尺度对照。")
    cov_rows = read_csv(RESULTS / "coverage_threshold_sensitivity.csv")
    lines.append("- 覆盖率阈值 60%/70%/80%/90%：四个阈值的完整核心集合均为 " + (cov_rows[0]["usable_complete_core_set"] if cov_rows else "八项核心指标") + "；未对扩展指标插值，主排名与 Kimi 名次均保持冻结口径。")
    lat_rows = read_csv(RESULTS / "q3_latency_threshold_summary.csv")
    for scenario in SCENARIOS:
        values = [f"{r['latency_threshold_seconds']}s→{r['feasible_count']}个" for r in lat_rows if r["scenario"] == scenario]
        lines.append(f"- {scenario}统一协议 E2E 时延代理边界敏感性：" + "、".join(values) + "；完整预算分段见 `q3_latency_threshold_segments.csv`。")
    cache_summary = read_csv(RESULTS / "q3_cache_sensitivity_summary.csv")
    lines.append("- 缓存命中敏感性基于 19 个具有正缓存命中价的配置，成本公式为 `input*((1-h)*pin+h*pcache)+output*pout`；h=0/0.3/0.6/0.9 的 Pareto 与预算路径见 `q3_cache_sensitivity_*.csv`。")
    workload_stability = read_csv(RESULTS / "q3_workload_pareto_stability.csv")
    if workload_stability:
        workload_summary = "；".join(
            f"{scenario}中等负载前沿={next(row['medium_frontier_size'] for row in workload_stability if row['scenario'] == scenario and row['comparison'] == 'medium_vs_light')}"
            for scenario in SCENARIOS
        )
        lines.append(f"- 工作负载 Pareto 稳定性采用质量、费用、E2E 时延三目标前沿（frontier_type=quality_cost_latency_3d）：{workload_summary}；轻/重负载与中等负载的 Jaccard 均为 1。二维质量–费用前沿仅保留为诊断字段。")
    mc_rows = read_csv(RESULTS / "robustness_pareto_monte_carlo.csv")
    mc_summary_rows = read_csv(RESULTS / "q3_pareto_monte_carlo_summary.csv")
    for scenario in SCENARIOS:
        top = sorted([r for r in mc_rows if r["scenario"] == scenario], key=lambda r: -float(r["pareto_stable_frequency"]))[:3]
        summary_row = next((r for r in mc_summary_rows if r["scenario"] == scenario), None)
        summary_text = f"平均前沿规模 {float(summary_row['mean_frontier_size']):.2f}，最高稳定频率 {float(summary_row['max_frequency']):.1%}（{summary_row['max_frequency_models']}）" if summary_row else ""
        lines.append(f"- {scenario} Monte Carlo Pareto 稳定频率（N={V3_MONTE_CARLO_DRAWS}，κ={V3_MONTE_CARLO_KAPPA}）：" + "、".join(f"{r['model_name']} {float(r['pareto_stable_frequency']):.1%}" for r in top) + f"；{summary_text}。每次从 L/M/H 和四档统一协议 E2E 时延代理边界等概率抽取，不满足 I_is(0.25) 资格或超过时延代理边界者当次不进前沿。")
    family_rows = read_csv(RESULTS / "robustness_model_family_summary.csv")
    if family_rows:
        lines.append(f"- 模型家族依赖性：在 {family_rows[0]['vendor_count']} 个共同厂商代表上比较最高通用分配置与最新发布配置，Kendall={float(family_rows[0]['kendall_tau']):.3f}、Top5重合率={float(family_rows[0]['top5_overlap']):.0%}；未把不同样本长度直接做 Kendall。")
    lomo_rows = read_csv(RESULTS / "q3_fit_leave_one_model_out_summary.csv")
    lines.append("- 成本性能回归留一模型检验：" + "；".join(f"{r['scenario']} 最优函数保持率={float(r['same_function_rate']):.1%}" for r in lomo_rows) + "；仅作函数选择影响审计，不作因果推断。")
    lines += [
        "",
        "## V2 变更与废止输出",
        "",
        "- 废止 `critic_weights.csv` 及旧 family/bootstrap 汇总；主模型改为透明指标映射、七项维度等权和 Dirichlet/需求扰动稳健性。",
        "- 新增 `quality_mapping.csv`、`task_chain_demands.csv`、`scenario_weights.csv`、`eligibility_thresholds.csv`、`q3_pareto_quality_cost_latency_*.csv`、三档 `q3_workload_costs_long.csv` 与 `q3_workload_pareto_stability.csv`。",
        "- `q3_pareto_*.csv` 与 `q3_budget_segments_*.csv` 已显式应用 I_is(0.25) 相对短板资格；不满足资格的正价配置仍保留在 20 配置成本表中作边界审计，但不参与主推荐。",
        "",
        f"验证状态：{'通过' if validation.get('passed') else '未通过'}（详细检查见 `results/validation.json` 与 `VALIDATION.md`）。",
    ]
    (RESULTS / "V2_RESULTS_REPORT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_readme() -> None:
    text = """# B题分析工程

该目录是问题一至问题三的可复算实现。程序只读取 `workstreams/aa_data_collection/` 中已冻结的正式表（`scores_long.csv`、`models.csv`、`benchmarks.csv`、`engineering_cost.csv`），不联网、不绕过 Premium，不把缺失值转换为 0 或列均值。

## 运行

在项目根目录执行：

```powershell
powershell -ExecutionPolicy Bypass -File workstreams/analysis_engine/run_all.ps1
```

或直接运行：

```powershell
python workstreams/analysis_engine/src/analyze.py
```

输出位于 `results/`，图表同时生成 SVG、PDF 和 PNG；PNG 用于逐图人工视觉检查，论文使用 SVG/PDF。

## 主模型口径

- C1：八项核心 Benchmark 完整的 27 个配置；C1 为 HLE/GPQA 等权，C2 为知识正确性，C3 为知识边界校准（底层 Non-Hallucination 指标），其余维度分列映射。
- 问题一采用七项核心评价维度等权，问题二按 `modeling/MODEL_SPEC_V2.md` 五任务链推导场景需求；速度和 E2E 仅属于工程层。
- 问题三：20 个正价且工程字段完整的配置，排除 Command A+，保留 Nemotron 3 Super；缓存命中率固定为 0。主 Pareto 与预算路径先应用每个场景 I_is(0.25) 相对短板资格，再使用场景综合得分 S_is、直接 token 费用与统一评测协议 E2E 时延代理三目标；T 不等同于本文工作负载下的场景响应时间，未通过资格的配置只保留在 20 配置成本审计表中。

## 关键结果文件

`rankings.csv`、`ability_scores.csv`、`quality_mapping.csv`、`all_high_corr_pairs.csv`、`correlation_metadata.json`、`figure_metadata.json`、`task_chain_demands.csv`、`scenario_task_matrix.csv`、`scenario_weights.csv`、`eligibility_thresholds.csv`、`scenario_decomposition.csv`、`q3_costs_long.csv`、`q3_pareto_*.csv`、`q3_pareto_quality_cost_latency_*.csv`、`q3_budget_segments_*.csv`、`q3_workload_costs_long.csv`、`q3_workload_pareto_stability.csv`、`q3_fit_summary.csv`、`q3_fit_leave_one_model_out*.csv`、`q3_latency_threshold_*.csv`、`q3_cache_sensitivity_*.csv`、`q3_pareto_monte_carlo_summary.csv`、`compute_proxy.csv`、`compute_proxy_sources.csv`、`compute_proxy_audit.csv`、`robustness_*.csv/json`、`coverage_admission.csv`、`coverage_threshold_*.csv`、`validation.json`、`V2_RESULTS_REPORT.md`（V3 检验版）。

## V3 检验分层

- 参数敏感性：覆盖率阈值 60/70/80/90%、场景需求 ±20%、L/M/H 工作负载、科研/日常/代码四档统一协议 E2E 时延代理边界、缓存命中率 0/0.3/0.6/0.9 和预算切换。
- 结构稳健性：分位数/Min-Max/Robust-Z、TOPSIS、留一 Benchmark、留一能力维度、模型家族代表层和留一模型成本回归。
- 结果不确定性：既有 Dirichlet 10,000 次与需求扰动，新增固定 seed 的 N=5,000 Monte Carlo Pareto 稳定频率。Monte Carlo 每次从既有 L/M/H 与本轮统一协议 E2E 时延代理边界网格等概率抽取；不满足 I_is(0.25) 或时延代理边界者当次不进入 Pareto，分母始终为 5,000。

## 数据边界

Artificial Analysis 的 `index_cost_per_task_usd` 与输入/输出 token 单价是不同量纲，程序只将前者原样保留在正式工程表中，绝不乘入问题三 token 成本。问题三预算/Pareto 只对 I_is(0.25) 资格配置使用场景综合得分 S_is、直接费用和统一评测协议下的 E2E 时延代理三目标；T 是工程响应效率代理，不等同于本文工作负载下的场景响应时间；图 9 在质量--费用平面投影三目标 Pareto，并以点颜色编码该时延代理。`compute_proxy` 仅作 2/8 覆盖的探索性负担代理，不是 kWh 或通用计算效率。闭源配置没有统一功率、硬件和运行时间观测，程序不输出统一口径的电力消耗量。
"""
    (OUT / "README.md").write_text(text, encoding="utf-8")


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    RESULTS.mkdir(parents=True, exist_ok=True)
    FIGURES.mkdir(parents=True, exist_ok=True)
    deprecated = ["critic_weights.csv", "robustness_family_representative.csv", "robustness_family_summary.json", "robustness_bootstrap_summary.json", "robustness_bootstrap_top_frequency.csv"]
    removed = []
    for filename in deprecated:
        path = RESULTS / filename
        if path.exists():
            path.unlink()
            removed.append(filename)
    write_json(RESULTS / "deprecated_outputs.json", {"removed_before_v2_run": removed, "deprecated": {"critic_weights.csv": "V2 uses transparent equal mapping and equal generic weights; no CRITIC output", "robustness_family_*.csv/json": "V2 keeps complete 27-model quality panel rather than family-CRITIC recomputation", "robustness_bootstrap_*.csv/json": "V2 reports Dirichlet and task-demand perturbations instead"}})
    names, score_by_model, api_by_model, _ = load_data()
    raw, _, _ = make_panel(names, score_by_model, api_by_model)
    analysis = analyze_scores(raw, names, normalization="quantile")
    write_core_outputs(names, raw, analysis, api_by_model)
    rho, linkage_matrix = correlation_outputs(names, raw)
    kimi_outputs(names, analysis)
    scenario_decomposition(names, analysis)
    compute_proxy = load_compute_proxy(names)
    scenario_rows = q3_outputs(names, analysis, api_by_model, compute_proxy)
    cost_fit_outputs(scenario_rows)
    robustness_outputs(names, raw, analysis, api_by_model, scenario_rows)
    figure_outputs(names, raw, analysis, rho, linkage_matrix, scenario_rows)
    validation = validate_outputs(names, raw, api_by_model, scenario_rows)
    write_results_report(names, analysis, scenario_rows, validation)
    write_readme()
    manifest = {
        "generated_at": datetime.now(timezone.utc).isoformat(), "seed": SEED, "entrypoint": str(Path(__file__).relative_to(ROOT)),
        "source_files": {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest() for path in [DATA_DIR / "scores_long.csv", DATA_DIR / "engineering_cost.csv", DATA_DIR / "models.csv", DATA_DIR / "benchmarks.csv", ROOT / "modeling" / "MODEL_SPEC_V2.md"]},
        "q1_q2_model_count": len(names), "q3_model_count": 20, "quality_dimension_count": len(ABILITIES), "validation_passed": validation["passed"],
    }
    write_json(RESULTS / "analysis_manifest.json", manifest)
    print(json.dumps({"passed": validation["passed"], "q1_q2_models": len(names), "q3_models": 20, "output": str(RESULTS)}, ensure_ascii=False))
    return 0 if validation["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
